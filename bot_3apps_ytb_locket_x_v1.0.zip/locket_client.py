# -*- coding: utf-8 -*-
"""
Locket Widget API Client thuần túy qua HTTP requests.
Không sử dụng Selenium / Playwright / Chromium. Chạy siêu nhẹ trên VPS/Termux.
Hỗ trợ:
- Đăng nhập trực tiếp bằng Tài khoản & Mật khẩu (Email|Password) qua Firebase Auth
- Tự động làm mới Token (Refresh Token) để treo liên tục không lo hết hạn
- Hoặc đăng nhập bằng Token JWT (Bearer Token)
- Tự động lấy danh sách đầy đủ Bạn Bè (Firestore + fetchUserV2)
- Tự động tạo ảnh và upload lên Firebase Storage (locket-img)
- Đăng ảnh/moment kèm caption lên Widget màn hình chính của Bạn Bè (postMoment)
- Hỗ trợ gửi cho nhiều bạn bè cụ thể được chọn (recipients) hoặc gửi cho All Bạn Bè (sent_to_all)
- Treo nhây Locket từ file TXT hoặc nội dung lặp lại
"""

import re
import os
import io
import uuid
import json
import time
import base64
import hashlib
import requests
import urllib.request
from typing import Dict, List, Optional, Tuple

class LocketClient:
    FIREBASE_API_KEY = "AIzaSyCQngaaXQIfJaH0aS2l7REgIjD7nL431So"
    FIREBASE_AUTH_URL = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword"
    FIREBASE_TOKEN_URL = "https://securetoken.googleapis.com/v1/token"

    def __init__(self, auth_input: str):
        self.raw_input = auth_input.strip()
        self.refresh_token = None
        self.email = None

        # Kiểm tra xem người dùng nhập Email|Mật khẩu hay Token JWT
        if self._is_email_password(self.raw_input):
            email, password = self._parse_email_password(self.raw_input)
            auth_data = self._login_firebase(email, password)
            self.id_token = auth_data["idToken"]
            self.refresh_token = auth_data.get("refreshToken")
            self.local_id = auth_data["localId"]
            self.email = auth_data.get("email", email)
            self.user_info = self._decode_jwt(self.id_token)
        else:
            self.id_token = self._clean_token(self.raw_input)
            self.user_info = self._decode_jwt(self.id_token)
            self.local_id = self.user_info.get("user_id") or self.user_info.get("sub")
            self.email = self.user_info.get("email")
            
            if not self.local_id:
                raise ValueError("Token Locket không hợp lệ hoặc sai định dạng email|mật_khẩu!")

        self.session = requests.Session()
        self.session.headers.update({
            "content-type": "application/json",
            "authorization": f"Bearer {self.id_token}",
            "user-agent": "com.locket.Locket/1.43.1 iPhone/17.3 hw/iPhone15_3",
            "accept": "*/*",
            "accept-language": "vi-VN,vi;q=0.9",
        })

    def _is_email_password(self, text: str) -> bool:
        if "Bearer " in text or text.startswith("eyJ"):
            return False
        if "@" in text and any(sep in text for sep in ["|", ":", "\t", " --- "]):
            return True
        return False

    def _parse_email_password(self, text: str) -> Tuple[str, str]:
        for sep in ["|", ":", "\t", " --- "]:
            if sep in text:
                parts = text.split(sep, 1)
                return parts[0].strip(), parts[1].strip()
        parts = text.split(None, 1)
        if len(parts) == 2:
            return parts[0].strip(), parts[1].strip()
        raise ValueError("Định dạng tài khoản Locket không hợp lệ! Vui lòng nhập: email|mật_khẩu")

    def _login_firebase(self, email: str, password: str) -> dict:
        """Đăng nhập Locket qua Firebase Auth REST API"""
        url = f"{self.FIREBASE_AUTH_URL}?key={self.FIREBASE_API_KEY}"
        headers = {
            "User-Agent": "com.locket.Locket/1.43.1 iPhone/17.3 hw/iPhone15_3",
            "X-Ios-Bundle-Identifier": "com.locket.Locket",
            "Content-Type": "application/json"
        }
        payload = {
            "email": email,
            "password": password,
            "returnSecureToken": True
        }
        r = requests.post(url, json=payload, headers=headers, timeout=12)
        res_data = r.json()
        
        if r.status_code != 200:
            err_msg = res_data.get("error", {}).get("message", "Lỗi đăng nhập")
            if "EMAIL_NOT_FOUND" in err_msg:
                raise RuntimeError(f"Email '{email}' chưa từng đăng ký tài khoản Locket!")
            elif "INVALID_PASSWORD" in err_msg or "INVALID_LOGIN_CREDENTIALS" in err_msg:
                raise RuntimeError(f"Sai mật khẩu cho tài khoản Locket '{email}'!")
            elif "USER_DISABLED" in err_msg:
                raise RuntimeError(f"Tài khoản Locket '{email}' đã bị vô hiệu hoá!")
            elif "TOO_MANY_ATTEMPTS" in err_msg:
                raise RuntimeError(f"Đăng nhập sai quá nhiều lần. Vui lòng thử lại sau ít phút!")
            else:
                raise RuntimeError(f"Lỗi đăng nhập Locket: {err_msg}")
                
        return res_data

    def refresh_token_if_needed(self):
        """Làm mới idToken tự động nếu có refreshToken"""
        if not self.refresh_token:
            return
        exp = self.user_info.get("exp", 0)
        now = time.time()
        # Nếu token còn hạn trên 5 phút thì chưa cần refresh
        if exp and (exp - now > 300):
            return

        url = f"{self.FIREBASE_TOKEN_URL}?key={self.FIREBASE_API_KEY}"
        headers = {
            "User-Agent": "com.locket.Locket/1.43.1 iPhone/17.3 hw/iPhone15_3",
            "X-Ios-Bundle-Identifier": "com.locket.Locket",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        data = {
            "grant_type": "refresh_token",
            "refresh_token": self.refresh_token
        }
        try:
            r = requests.post(url, data=data, headers=headers, timeout=10)
            if r.status_code == 200:
                res = r.json()
                self.id_token = res["id_token"]
                self.refresh_token = res.get("refresh_token", self.refresh_token)
                self.user_info = self._decode_jwt(self.id_token)
                self.session.headers.update({"authorization": f"Bearer {self.id_token}"})
        except Exception:
            pass

    def _clean_token(self, text: str) -> str:
        if "Bearer " in text:
            text = text.split("Bearer ")[-1].strip()
        m = re.search(r'(eyJ[a-zA-Z0-9_\-\.]+)', text)
        if m:
            return m.group(1).strip()
        return text.strip()

    def _decode_jwt(self, jwt_str: str) -> dict:
        try:
            parts = jwt_str.split('.')
            if len(parts) >= 2:
                payload = parts[1]
                padded = payload + '=' * (-len(payload) % 4)
                decoded = base64.urlsafe_b64decode(padded.encode('utf-8'))
                return json.loads(decoded.decode('utf-8'))
        except Exception:
            pass
        return {}

    def get_self(self) -> Dict[str, str]:
        """Lấy thông tin tài khoản Locket"""
        self.refresh_token_if_needed()
        exp = self.user_info.get("exp", 0)
        now = time.time()
        if exp and exp < now and not self.refresh_token:
            raise RuntimeError("Token Locket đã hết hạn phiên đăng nhập (JWT Expired)!")

        uid = self.local_id
        email = self.email or self.user_info.get("email", "Locket User")
        name = self.user_info.get("name") or self.user_info.get("display_name") or email.split("@")[0]
        
        return {
            "uid": uid,
            "name": name,
            "email": email,
            "exp": exp
        }

    def get_friends(self) -> List[Dict[str, str]]:
        """Lấy danh sách đầy đủ bạn bè Locket (Firestore + fetchUserV2)"""
        self.refresh_token_if_needed()
        token = self.id_token
        my_uid = self.local_id
        friends = []

        try:
            url_fs = f"https://firestore.googleapis.com/v1/projects/locket-4252a/databases/(default)/documents/users/{my_uid}/friends"
            req_fs = urllib.request.Request(url_fs, headers={"Authorization": f"Bearer {token}"})
            with urllib.request.urlopen(req_fs, timeout=12) as resp:
                data_fs = json.loads(resp.read().decode("utf-8"))

            for doc in data_fs.get("documents", []):
                fuid = doc["name"].split("/")[-1]
                url_u = "https://api.locketcamera.com/fetchUserV2"
                headers_u = {
                    "User-Agent": "com.locket.Locket/1.43.1 iPhone/17.3 hw/iPhone15_3",
                    "x-ios-bundle-identifier": "com.locket.Locket",
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json; charset=utf-8",
                    "Accept": "*/*"
                }
                payload_u = {"data": {"user_uid": fuid}}
                req_u = urllib.request.Request(url_u, data=json.dumps(payload_u).encode("utf-8"), headers=headers_u)
                try:
                    with urllib.request.urlopen(req_u, timeout=8) as resp_u:
                        res_json = json.loads(resp_u.read().decode("utf-8"))
                        u_data = res_json.get("result", {}).get("data", {})
                        first = u_data.get("first_name", "")
                        last = u_data.get("last_name", "")
                        uname = u_data.get("username", "")
                        name = f"{first} {last}".strip() or uname or fuid
                        friends.append({"uid": fuid, "id": fuid, "name": name, "username": uname})
                except Exception:
                    friends.append({"uid": fuid, "id": fuid, "name": fuid, "username": ""})
        except Exception:
            pass

        return friends

    def _create_default_image(self, text_watermark: str = "") -> bytes:
        """Tạo ảnh JPEG 800x800 chuẩn tối ưu để hiển thị trên Widget iOS/Android"""
        try:
            from PIL import Image, ImageDraw
            img = Image.new('RGB', (800, 800), color=(18, 18, 20))
            draw = ImageDraw.Draw(img)
            
            # Viền bo màu vàng đặc trưng của Locket
            draw.rectangle([20, 20, 780, 780], outline=(254, 219, 0), width=6)
            
            display_text = text_watermark[:100] if text_watermark else "💛 Locket Widget"
            draw.text((400, 400), display_text, fill=(255, 255, 255), anchor="mm")
            
            buf = io.BytesIO()
            img.save(buf, format='JPEG', quality=90)
            return buf.getvalue()
        except Exception:
            minimal_jpg = bytes([
                0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x01, 0x00, 0x48,
                0x00, 0x48, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
                0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
                0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
                0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
                0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
                0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x1F, 0x00, 0x00, 0x01, 0x05, 0x01, 0x01,
                0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04,
                0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F,
                0x00, 0xBF, 0x80, 0xFF, 0xD9
            ])
            return minimal_jpg

    def upload_thumbnail(self, image_bytes: bytes) -> str:
        """Upload ảnh lên Firebase Storage và lấy thumbnail_url kèm token"""
        self.refresh_token_if_needed()
        name_img = f"{uuid.uuid4().hex}.jpg"
        image_size = len(image_bytes)
        local_id = self.local_id
        
        # 1. Start Resumable Upload
        init_headers = {
            "content-type": "application/json; charset=UTF-8",
            "authorization": f"Bearer {self.id_token}",
            "x-goog-upload-protocol": "resumable",
            "accept": "*/*",
            "x-goog-upload-command": "start",
            "x-goog-upload-content-length": str(image_size),
            "accept-language": "vi-VN,vi;q=0.9",
            "x-firebase-storage-version": "ios/10.13.0",
            "user-agent": "com.locket.Locket/1.43.1 iPhone/17.3 hw/iPhone15_3 (GTMSUF/1)",
            "x-goog-upload-content-type": "image/jpeg",
            "x-firebase-gmpid": "1:641029076083:ios:cc8eb46290d69b234fa606",
        }
        
        init_data = json.dumps({
            "name": f"users/{local_id}/moments/thumbnails/{name_img}",
            "contentType": "image/jpeg",
            "bucket": "",
            "metadata": {
                "creator": local_id,
                "visibility": "private"
            }
        })
        
        init_url = (
            f"https://firebasestorage.googleapis.com:443/v0/b/locket-img/o/users%2F{local_id}%2Fmoments%2Fthumbnails%2F{name_img}"
            f"?uploadType=resumable&name=users%2F{local_id}%2Fmoments%2Fthumbnails%2F{name_img}"
        )
        
        r_init = requests.post(init_url, headers=init_headers, data=init_data, timeout=15)
        if r_init.status_code not in (200, 201) or "X-Goog-Upload-URL" not in r_init.headers:
            raise RuntimeError(f"Lỗi khởi tạo upload Firebase Locket: HTTP {r_init.status_code} - {r_init.text[:120]}")

        upload_url = r_init.headers["X-Goog-Upload-URL"]
        
        # 2. Upload Binary & Finalize
        put_headers = {
            "content-type": "application/octet-stream",
            "x-goog-upload-protocol": "resumable",
            "x-goog-upload-offset": "0",
            "x-goog-upload-command": "upload, finalize",
            "upload-incomplete": "?0",
            "upload-draft-interop-version": "3",
            "user-agent": "com.locket.Locket/1.43.1 iPhone/17.3 hw/iPhone15_3 (GTMSUF/1)",
        }
        
        r_put = requests.put(upload_url, headers=put_headers, data=image_bytes, timeout=20)
        if r_put.status_code not in (200, 201):
            raise RuntimeError(f"Lỗi upload ảnh Firebase Locket: HTTP {r_put.status_code} - {r_put.text[:120]}")

        resp_json = r_put.json()
        download_tokens = resp_json.get("downloadTokens") or ""
        
        thumbnail_url = (
            f"https://firebasestorage.googleapis.com:443/v0/b/locket-img/o/users%2F{local_id}%2Fmoments%2Fthumbnails%2F{name_img}"
            f"?alt=media&token={download_tokens}"
        )
        return thumbnail_url

    def post_moment(self, caption: str = "", recipients: Optional[List[str]] = None, image_bytes: Optional[bytes] = None, sent_to_all: bool = True) -> bool:
        """Đăng Moment lên Locket Widget của bạn bè hoặc All Friends"""
        self.refresh_token_if_needed()
        if not image_bytes:
            image_bytes = self._create_default_image(caption)
            
        thumbnail_url = self.upload_thumbnail(image_bytes)
        md5_hash = hashlib.md5(image_bytes).hexdigest()
        
        url = "https://api.locketcamera.com/postMoment"
        payload = {
            "data": {
                "analytics": {
                    "platform": "ios",
                    "google_analytics": {
                        "app_instance_id": str(uuid.uuid4()).replace("-", "").upper()
                    },
                    "amplitude": {
                        "device_id": str(uuid.uuid4()).upper(),
                        "session_id": {
                            "@type": "type.googleapis.com/google.protobuf.Int64Value",
                            "value": str(int(time.time() * 1000))
                        }
                    }
                },
                "thumbnail_url": thumbnail_url,
                "caption": caption,
                "sent_to_all": bool(sent_to_all),
                "migration": {"database": "locket"},
                "recipients": recipients or [],
                "md5": md5_hash
            }
        }
        
        r = self.session.post(url, json=payload, timeout=15)
        if r.status_code in (200, 201):
            return True
        elif r.status_code in (401, 403):
            raise RuntimeError(f"Phiên Locket hết hạn hoặc không có quyền đăng (HTTP {r.status_code})")
        else:
            raise RuntimeError(f"Lỗi đăng Moment Locket (HTTP {r.status_code}): {r.text[:120]}")

    def send_chat_message(self, receiver_uid: str, text: str) -> dict:
        """Gửi tin nhắn riêng (Direct Message / Chat 1-1) tới bạn bè trên Locket qua sendChatMessageV2"""
        self.refresh_token_if_needed()
        token = self.id_token
        client_token = str(uuid.uuid4()).upper()

        url = "https://api.locketcamera.com/sendChatMessageV2"
        headers = {
            "User-Agent": "com.locket.Locket/2.68.0 iPhone/17.6.1 hw/iPhone15_2",
            "x-ios-bundle-identifier": "com.locket.Locket",
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "*/*"
        }

        payload = {
            "data": {
                "receiver_uid": receiver_uid,
                "msg": text,
                "moment_uid": None,
                "from_memory": False,
                "intensity": {
                    "value": "0",
                    "@type": "type.googleapis.com/google.protobuf.Int64Value"
                },
                "client_token": client_token,
                "analytics": {
                    "ios_version": "2.68.0.2523",
                    "experiments": {
                        "flag_18": {"@type": "type.googleapis.com/google.protobuf.Int64Value", "value": "1203"},
                        "flag_7": {"@type": "type.googleapis.com/google.protobuf.Int64Value", "value": "800"},
                        "flag_10": {"@type": "type.googleapis.com/google.protobuf.Int64Value", "value": "505"}
                    },
                    "installation_id": uuid.uuid4().hex[:22],
                    "platform": "ios"
                }
            }
        }

        req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=12) as resp:
                res = json.loads(resp.read().decode("utf-8"))
                return res.get("result", res)
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8", errors="ignore")
            if e.code in (401, 403):
                if self.refresh_token:
                    self.refresh_token_if_needed()
                    headers["Authorization"] = f"Bearer {self.id_token}"
                    req2 = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers)
                    try:
                        with urllib.request.urlopen(req2, timeout=12) as resp2:
                            res2 = json.loads(resp2.read().decode("utf-8"))
                            return res2.get("result", res2)
                    except Exception:
                        pass
                raise RuntimeError(f"Phiên Locket hết hạn hoặc lỗi xác thực (HTTP {e.code}): {err_body[:100]}")
            raise RuntimeError(f"Lỗi gửi tin nhắn Locket HTTP {e.code}: {err_body[:100]}")
        except Exception as e:
            raise RuntimeError(f"Lỗi kết nối Locket: {str(e)}")

