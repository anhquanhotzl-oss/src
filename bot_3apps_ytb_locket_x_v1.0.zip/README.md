# ⚡ BOT TELEGRAM 3 APPS CHUYÊN DỤNG (YOUTUBE, LOCKET, X)

Hệ thống Bot Telegram độc lập, gọn nhẹ, chuyên dụng cho **Treo Ngôn Tự Động** trên 3 nền tảng:
1. **▶️ YouTube:** Treo ngôn bình luận Video & Live Stream liên tục (sử dụng InnerTube API & SAPISIDHASH).
2. **💛 Locket:** Treo ngôn spam khoảnh khắc widget màn hình chính (hỗ trợ Firebase Auth hoặc JWT Bearer Token, gửi tới bạn bè cụ thể hoặc tất cả bạn bè).
3. **✖️ X (Twitter):** Treo DMs gửi tin nhắn riêng 1-1 tự động giải mã username sang UID và hỗ trợ fallback X Chat E2EE.

---

## 🚀 CÁCH KHỞI CHẠY BOT

### 1. Cài đặt thư viện:
```bash
pip install -r requirements.txt
```

### 2. Chạy Bot:
```bash
python bot.py
```

---

## 👑 QUẢN TRỊ VIÊN & HỆ THỐNG THUÊ BOT
- **Master Admin ID:** `7454964260`
- **Username Admin:** `@dzimeomeo`
- **Link liên hệ:** https://t.me/dzimeomeo
- **Chế độ bảo vệ:** Người dùng chưa được cấp quyền khi nhắn tin vào bot sẽ nhận thông báo yêu cầu thuê bot kèm nút liên hệ trực tiếp tới Admin `@dzimeomeo`.
- **Thêm Admin phụ:** Nhập Telegram ID -> Bot tự tra cứu Tên & Username -> Hiển thị nút Xác nhận trước khi thêm.
