# -*- coding: utf-8 -*-
"""
Unit test kiểm thử toàn diện cho Bot 3 Apps Mini.
"""
import sys
import os
import time
import threading

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
import bot as mini_bot
from youtube_helper import parse_yt_video_id, extract_yt_sapisid, get_yt_auth_header
from locket_client import LocketClient
from twitter_client import TwitterClient

def test_config_and_auth():
    print("[1] Kiểm tra cấu hình và phân quyền Admin:")
    assert config.MASTER_ADMIN_ID == 7454964260, "Sai Master Admin ID!"
    assert config.ADMIN_USERNAME == "@dzimeomeo", "Sai Admin Username!"
    assert mini_bot.is_admin(7454964260) == True, "Master Admin phải được cấp quyền!"
    assert mini_bot.is_admin(9999999999) == False, "UID lạ không được có quyền!"
    print(" -> Auth & Config OK!")

def test_youtube_helper():
    print("[2] Kiểm tra YouTube Helper:")
    # Test regex video ID
    assert parse_yt_video_id("https://www.youtube.com/watch?v=dQw4w9WgXcQ") == "dQw4w9WgXcQ"
    assert parse_yt_video_id("https://youtu.be/dQw4w9WgXcQ") == "dQw4w9WgXcQ"
    assert parse_yt_video_id("https://www.youtube.com/live/abcdefghijk") == "abcdefghijk"
    assert parse_yt_video_id("https://www.youtube.com/shorts/12345678901") == "12345678901"
    assert parse_yt_video_id("dQw4w9WgXcQ") == "dQw4w9WgXcQ"

    # Test cookie sapisid extraction
    raw_cookie = "VISITOR_INFO1_LIVE=xyz; SAPISID=abcdef123456; HSID=test"
    sapisid = extract_yt_sapisid(raw_cookie)
    assert sapisid == "abcdef123456", f"Trích xuất SAPISID sai: {sapisid}"

    # Test SAPISIDHASH
    auth = get_yt_auth_header(sapisid)
    assert auth.startswith("SAPISIDHASH "), f"Sai định dạng auth header: {auth}"
    print(" -> YouTube Helper OK!")

def test_locket_client():
    print("[3] Kiểm tra Locket Client:")
    # Test with valid JWT dummy payload containing user_id
    import base64
    import json
    header = base64.urlsafe_b64encode(b'{"alg":"none"}').decode().rstrip("=")
    payload = base64.urlsafe_b64encode(json.dumps({"user_id": "test_locket_uid_123", "email": "test@locket.app"}).encode()).decode().rstrip("=")
    fake_jwt = f"Bearer {header}.{payload}.signature"
    client = LocketClient(fake_jwt)
    assert client.local_id == "test_locket_uid_123"
    assert client.email == "test@locket.app"
    assert client._is_email_password("test@example.com|password123") == True
    email, pwd = client._parse_email_password("test@example.com|password123")
    assert email == "test@example.com"
    assert pwd == "password123"
    print(" -> Locket Client OK!")

def test_twitter_client():
    print("[4] Kiểm tra Twitter Client:")
    cookie_str = "auth_token=abc123xyz; ct0=csrf456; twid=u%3D12345678"
    cookie_dict = TwitterClient.parse_cookie(cookie_str)
    assert cookie_dict["auth_token"] == "abc123xyz"
    assert cookie_dict["ct0"] == "csrf456"
    assert cookie_dict["twid"] == "u%3D12345678"
    print(" -> Twitter Client OK!")

def test_task_manager():
    print("[5] Kiểm tra Task Manager Lifecycle:")
    tid = mini_bot.generate_task_id("TEST")
    stop_event = threading.Event()
    pause_event = threading.Event()

    task_info = {
        "id": tid,
        "app": "TestApp",
        "target": "Target123",
        "status": "running",
        "sent_count": 0,
        "fail_count": 0,
        "last_log": "Starting",
        "stop_event": stop_event,
        "pause_event": pause_event
    }
    mini_bot.tasks[tid] = task_info

    # Test Pause
    pause_event.set()
    task_info["status"] = "paused"
    assert mini_bot.tasks[tid]["status"] == "paused"

    # Test Resume
    pause_event.clear()
    task_info["status"] = "running"
    assert mini_bot.tasks[tid]["status"] == "running"

    # Test Stop
    stop_event.set()
    task_info["status"] = "stopped"
    assert mini_bot.tasks[tid]["status"] == "stopped"

    # Cleanup
    mini_bot.tasks.pop(tid, None)
    print(" -> Task Manager Lifecycle OK!")

if __name__ == "__main__":
    print("=== CHẠY UNIT TEST BOT 3 APPS MINI ===")
    test_config_and_auth()
    test_youtube_helper()
    test_locket_client()
    test_twitter_client()
    test_task_manager()
    print("=== TẤT CẢ TEST ĐÃ HOÀN TẤT VÀ VƯỢT QUA 100%! ===")
