# -*- coding: utf-8 -*-
"""
HỆ THỐNG BOT TELEGRAM 3 APPS CHUYÊN DỤNG (YOUTUBE, LOCKET, X/TWITTER)
Phiên bản Standalone - Treo Ngôn Đỉnh Cao
Admin Master: 7454964260 (@dzimeomeo)
"""

import os
import sys
import time
import json
import random
import string
import logging
import threading
from datetime import datetime
from typing import Dict, Any, List, Optional

import requests
import telebot
from telebot import types

# Import modules nội bộ
import config
from youtube_helper import (
    parse_and_clean_cookie as parse_yt_cookie,
    extract_yt_sapisid,
    get_yt_account_info,
    get_yt_video_info,
    get_yt_comment_params,
    send_yt_comment,
    parse_yt_video_id
)
from locket_client import LocketClient
from twitter_client import TwitterClient

# Cấu hình logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("Bot3Apps")

bot = telebot.TeleBot(config.BOT_TOKEN, parse_mode=None)

# ==============================================================================
# QUẢN LÝ ADMIN & PHÂN QUYỀN (RENTAL PROTECTION)
# ==============================================================================
cached_admins = set()

def load_admins() -> set:
    global cached_admins
    admins = {config.MASTER_ADMIN_ID}
    if os.path.exists(config.ADMINS_FILE):
        try:
            with open(config.ADMINS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    for item in data:
                        try:
                            admins.add(int(item))
                        except Exception:
                            pass
        except Exception as e:
            logger.error(f"Lỗi load admins.json: {e}")
    cached_admins = admins
    return cached_admins

def save_admins():
    global cached_admins
    try:
        with open(config.ADMINS_FILE, "w", encoding="utf-8") as f:
            json.dump(list(cached_admins), f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Lỗi save admins.json: {e}")

load_admins()

def is_admin(user_id: int) -> bool:
    return int(user_id) in cached_admins or int(user_id) == config.MASTER_ADMIN_ID

def check_auth(user_id: int, chat_id: Optional[int] = None) -> bool:
    if is_admin(user_id):
        return True
    if chat_id:
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton(f"💬 Liên Hệ Thuê Bot ({config.ADMIN_USERNAME})", url=config.ADMIN_CONTACT_URL))
        text = (
            "⛔ <b>BẠN CHƯA CÓ QUYỀN SỬ DỤNG BOT!</b>\n\n"
            "⚠️ Bạn cần phải thuê bot để kích hoạt hệ thống treo ngôn.\n"
            f"🆔 <b>ID Telegram của bạn:</b> <code>{user_id}</code>\n\n"
            "📩 <i>Nếu bạn đã thanh toán thuê bot, vui lòng bấm nút bên dưới để nhắn tin cho Admin cấp quyền sử dụng!</i>"
        )
        try:
            bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=markup)
        except Exception:
            pass
    return False

# ==============================================================================
# QUẢN LÝ TASK (TASK MANAGER)
# ==============================================================================
tasks: Dict[str, Dict[str, Any]] = {}
user_states: Dict[int, Dict[str, Any]] = {}

def generate_task_id(prefix: str) -> str:
    return f"{prefix}_{int(time.time())}_{random.randint(100, 999)}"

# ==============================================================================
# KEYBOARD GIAO DIỆN CHÍNH
# ==============================================================================
def get_main_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    markup.add(
        types.KeyboardButton("▶️ YouTube Treo Ngôn"),
        types.KeyboardButton("💛 Locket Treo Ngôn")
    )
    markup.add(
        types.KeyboardButton("✖️ X (Twitter) Treo DMs"),
        types.KeyboardButton("📋 Quản Lý Task")
    )
    markup.add(
        types.KeyboardButton("👥 Quản Lý Admin"),
        types.KeyboardButton("ℹ️ Hướng Dẫn")
    )
    return markup

def get_cancel_keyboard():
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("❌ Hủy Thao Tác", callback_data="cancel_action"))
    return markup

# ==============================================================================
# WORKERS CHUYÊN BIỆT CHO TỪNG APP
# ==============================================================================

def worker_youtube(task_id: str, cookie_str: str, video_id: str, messages: List[str], delay: float):
    logger.info(f"[{task_id}] Khởi chạy Worker YouTube cho Video {video_id}")
    task = tasks.get(task_id)
    if not task:
        return

    sapisid = extract_yt_sapisid(cookie_str)
    session = requests.Session()
    msg_idx = 0
    fail_in_row = 0

    # Lấy thông số InnerTube ban đầu
    api_key, client_ver, create_params = get_yt_comment_params(session, video_id, cookie_str, sapisid)
    if not create_params:
        task["last_log"] = "Không lấy được createCommentParams từ video (Video tắt cmt hoặc Cookie hết hạn)"
        logger.error(f"[{task_id}] {task['last_log']}")

    while not task["stop_event"].is_set():
        if task["pause_event"].is_set():
            time.sleep(1)
            continue

        # Nếu chưa có params hoặc bị lỗi liên tục thì lấy lại params
        if not create_params or fail_in_row >= 3:
            time.sleep(2)
            api_key, client_ver, create_params = get_yt_comment_params(session, video_id, cookie_str, sapisid)
            if not create_params:
                task["fail_count"] += 1
                task["last_log"] = "Lỗi làm mới cmt params, thử lại sau..."
                time.sleep(max(delay, 5))
                continue
            else:
                fail_in_row = 0

        # Chuẩn bị nội dung ngôn
        current_msg = messages[msg_idx % len(messages)]
        msg_idx += 1
        # Thêm đuôi ngẫu nhiên nhẹ chống trùng cmt YouTube
        rand_suffix = "".join(random.choices(string.ascii_letters + string.digits, k=3))
        full_comment = f"{current_msg} [{rand_suffix}]" if len(messages) == 1 else current_msg

        success, err = send_yt_comment(session, api_key, client_ver, create_params, cookie_str, sapisid, full_comment)
        if success:
            task["sent_count"] += 1
            fail_in_row = 0
            task["last_log"] = f"Gửi comment thành công: {full_comment[:30]}..."
            logger.info(f"[{task_id}] Comment thành công #{task['sent_count']}")
        else:
            task["fail_count"] += 1
            fail_in_row += 1
            task["last_log"] = f"Lỗi gửi comment: {err[:50]}"
            logger.warning(f"[{task_id}] Comment lỗi #{task['fail_count']}: {err}")

        # Sleep theo delay
        slept = 0.0
        while slept < delay and not task["stop_event"].is_set():
            time.sleep(min(0.5, delay - slept))
            slept += 0.5

    task["status"] = "stopped"
    logger.info(f"[{task_id}] Worker YouTube đã dừng!")


def worker_locket(task_id: str, auth_str: str, target_uid: str, messages: List[str], delay: float):
    logger.info(f"[{task_id}] Khởi chạy Worker Locket cho Target {target_uid}")
    task = tasks.get(task_id)
    if not task:
        return

    client = LocketClient(auth_str)
    msg_idx = 0

    while not task["stop_event"].is_set():
        if task["pause_event"].is_set():
            time.sleep(1)
            continue

        current_msg = messages[msg_idx % len(messages)]
        msg_idx += 1

        recipients = None if target_uid.lower() == "all" else [target_uid]
        success, res = client.post_moment(caption=current_msg, recipients=recipients)
        if success:
            task["sent_count"] += 1
            task["last_log"] = f"Đã đăng khoảnh khắc: {current_msg[:30]}..."
            logger.info(f"[{task_id}] Locket gửi thành công #{task['sent_count']}")
        else:
            task["fail_count"] += 1
            task["last_log"] = f"Lỗi Locket: {str(res)[:50]}"
            logger.warning(f"[{task_id}] Locket lỗi #{task['fail_count']}: {res}")

        slept = 0.0
        while slept < delay and not task["stop_event"].is_set():
            time.sleep(min(0.5, delay - slept))
            slept += 0.5

    task["status"] = "stopped"
    logger.info(f"[{task_id}] Worker Locket đã dừng!")


def worker_x(task_id: str, cookie_str: str, recipient_id: str, messages: List[str], delay: float):
    logger.info(f"[{task_id}] Khởi chạy Worker X DMs cho Recipient {recipient_id}")
    task = tasks.get(task_id)
    if not task:
        return

    client = TwitterClient(cookie_str)
    msg_idx = 0

    while not task["stop_event"].is_set():
        if task["pause_event"].is_set():
            time.sleep(1)
            continue

        current_msg = messages[msg_idx % len(messages)]
        msg_idx += 1

        success, res = client.send_dm(recipient_id=recipient_id, text=current_msg)
        if success:
            task["sent_count"] += 1
            task["last_log"] = f"Đã gửi DM: {current_msg[:30]}..."
            logger.info(f"[{task_id}] X DM thành công #{task['sent_count']}")
        else:
            task["fail_count"] += 1
            task["last_log"] = f"Lỗi X DM: {str(res)[:50]}"
            logger.warning(f"[{task_id}] X DM lỗi #{task['fail_count']}: {res}")

        slept = 0.0
        while slept < delay and not task["stop_event"].is_set():
            time.sleep(min(0.5, delay - slept))
            slept += 0.5

    task["status"] = "stopped"
    logger.info(f"[{task_id}] Worker X DMs đã dừng!")

# ==============================================================================
# LỆNH VÀ ĐIỀU HƯỚNG CƠ BẢN
# ==============================================================================

@bot.message_handler(commands=['start', 'menu'])
def handle_start(message: types.Message):
    user_id = message.from_user.id
    if not check_auth(user_id, message.chat.id):
        return

    user_states.pop(user_id, None)
    welcome_text = (
        "⚡ <b>HỆ THỐNG BOT 3 APPS CHUYÊN DỤNG</b> ⚡\n"
        "<i>Phiên bản độc lập - Treo ngôn siêu tốc & êm mượt</i>\n\n"
        "🎯 <b>DANH SÁCH 3 ỨNG DỤNG HỖ TRỢ:</b>\n"
        "1. ▶️ <b>YouTube:</b> Treo ngôn bình luận Video / Live Stream liên tục.\n"
        "2. 💛 <b>Locket:</b> Treo ngôn spam ảnh widget màn hình chính.\n"
        "3. ✖️ <b>X (Twitter):</b> Treo DMs gửi tin nhắn riêng 1-1 tới người dùng.\n\n"
        "📌 <i>Chọn chức năng bên dưới bàn phím để bắt đầu thiết lập!</i>"
    )
    bot.send_message(message.chat.id, welcome_text, parse_mode="HTML", reply_markup=get_main_keyboard())


@bot.message_handler(commands=['cancel'])
def handle_cancel(message: types.Message):
    user_id = message.from_user.id
    if not check_auth(user_id, message.chat.id):
        return
    user_states.pop(user_id, None)
    bot.send_message(message.chat.id, "✅ Đã hủy thao tác hiện tại! Sếp có thể chọn chức năng mới.", reply_markup=get_main_keyboard())


@bot.message_handler(commands=['help'])
@bot.message_handler(func=lambda m: m.text == "ℹ️ Hướng Dẫn")
def handle_help(message: types.Message):
    user_id = message.from_user.id
    if not check_auth(user_id, message.chat.id):
        return

    text = (
        "📖 <b>HƯỚNG DẪN SỬ DỤNG BOT 3 APPS CHUYÊN DỤNG:</b>\n\n"
        "▶️ <b>1. YOUTUBE TREO NGÔN:</b>\n"
        "• Bấm nút <code>▶️ YouTube Treo Ngôn</code>.\n"
        "• Nạp Cookie YouTube (cần có <code>SAPISID</code> hoặc <code>__Secure-3PAPISID</code>).\n"
        "• Dán link Video hoặc Video ID (vd: <code>dQw4w9WgXcQ</code>).\n"
        "• Nhập nội dung câu ngôn hoặc gửi file <code>.txt</code> chứa danh sách ngôn.\n"
        "• Nhập delay giây (khuyên dùng từ 3s trở lên) để bắt đầu.\n\n"
        "💛 <b>2. LOCKET TREO NGÔN:</b>\n"
        "• Bấm nút <code>💛 Locket Treo Ngôn</code>.\n"
        "• Nhập tài khoản dạng <code>email|password</code> hoặc Token Bearer.\n"
        "• Nhập UID bạn bè nhận (hoặc nhập <code>all</code> để spam tất cả bạn bè).\n"
        "• Nhập câu ngôn hoặc gửi file <code>.txt</code> -> Chọn delay (từ 1s - 3s).\n\n"
        "✖️ <b>3. X (TWITTER) TREO DMS:</b>\n"
        "• Bấm nút <code>✖️ X (Twitter) Treo DMs</code>.\n"
        "• Nạp Cookie X (có <code>auth_token</code> và <code>ct0</code>).\n"
        "• Nhập <code>@username</code> hoặc UID người nhận -> Bot tự động tra cứu ID.\n"
        "• Nhập câu ngôn hoặc gửi file <code>.txt</code> -> Chọn delay để khởi chạy.\n\n"
        "📋 <b>QUẢN LÝ TASK:</b>\n"
        "• Xem trạng thái, tạm dừng, tiếp tục hoặc dừng hẳn bất kỳ task nào đang chạy.\n\n"
        "👑 <b>ADMIN:</b> Quản lý phân quyền thuê bot và danh sách quản trị viên."
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_main_keyboard())

# ==============================================================================
# LUỒNG 1: YOUTUBE TREO NGÔN
# ==============================================================================

@bot.message_handler(func=lambda m: m.text == "▶️ YouTube Treo Ngôn")
def start_yt_flow(message: types.Message):
    user_id = message.from_user.id
    if not check_auth(user_id, message.chat.id):
        return

    user_states[user_id] = {"action": "yt_cookie", "data": {}}
    text = (
        "▶️ <b>THIẾT LẬP TREO NGÔN YOUTUBE (BÌNH LUẬN VIDEO / LIVE)</b>\n\n"
        "👉 <b>Bước 1/4:</b> Sếp vui lòng gửi <b>Cookie YouTube</b> của tài khoản.\n"
        "<i>(Cookie phải chứa chuỗi <code>SAPISID=...</code> hoặc <code>__Secure-3PAPISID=...</code>)</i>\n\n"
        "<i>Sếp có thể dán trực tiếp cookie vào đây hoặc bấm Hủy bên dưới:</i>"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_yt_cookie(message: types.Message, cookie_raw: str):
    user_id = message.from_user.id
    sapisid = extract_yt_sapisid(cookie_raw)
    if not sapisid:
        bot.send_message(
            message.chat.id,
            "❌ <b>Cookie không hợp lệ!</b> Không tìm thấy SAPISID trong Cookie.\n"
            "Vui lòng copy lại toàn bộ Cookie trên trình duyệt và gửi lại:",
            parse_mode="HTML",
            reply_markup=get_cancel_keyboard()
        )
        return

    # Kiểm tra tài khoản YouTube
    info = get_yt_account_info(cookie_raw)
    acc_name = info.get("name", "Người dùng YouTube")

    user_states[user_id]["data"]["cookie"] = cookie_raw
    user_states[user_id]["action"] = "yt_target"

    text = (
        f"✅ <b>Nhận diện tài khoản:</b> <code>{acc_name}</code>\n\n"
        "👉 <b>Bước 2/4:</b> Sếp gửi <b>Link Video YouTube</b> hoặc <b>Video ID</b> cần treo cmt:\n"
        "<i>(Ví dụ: <code>https://www.youtube.com/watch?v=dQw4w9WgXcQ</code> hoặc <code>dQw4w9WgXcQ</code>)</i>"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_yt_target(message: types.Message, target_raw: str):
    user_id = message.from_user.id
    vid_id = parse_yt_video_id(target_raw)
    if not vid_id:
        bot.send_message(message.chat.id, "❌ Không nhận diện được Video ID. Vui lòng gửi lại link video:", reply_markup=get_cancel_keyboard())
        return

    info = get_yt_video_info(vid_id)
    v_title = info.get("title", f"Video {vid_id}")
    v_owner = info.get("owner", "YouTube")

    user_states[user_id]["data"]["video_id"] = vid_id
    user_states[user_id]["data"]["video_title"] = v_title
    user_states[user_id]["action"] = "yt_msg"

    text = (
        f"🎯 <b>Mục tiêu Video:</b>\n"
        f"• <b>Tiêu đề:</b> {v_title}\n"
        f"• <b>Kênh:</b> {v_owner}\n"
        f"• <b>ID:</b> <code>{vid_id}</code>\n\n"
        "👉 <b>Bước 3/4:</b> Sếp nhập <b>Nội Dung Ngôn</b> cần treo:\n"
        "• Gõ câu ngôn trực tiếp vào đây.\n"
        "• Hoặc gửi <b>File .TXT</b> chứa danh sách các câu ngôn (mỗi dòng 1 câu để xoay vòng)!"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_yt_msg(message: types.Message, msgs: List[str]):
    user_id = message.from_user.id
    user_states[user_id]["data"]["messages"] = msgs
    user_states[user_id]["action"] = "yt_delay"

    sample = msgs[0] if len(msgs) == 1 else f"{len(msgs)} câu ngôn xoay vòng (VD: {msgs[0][:20]}...)"
    text = (
        f"📝 <b>Đã nhận nội dung:</b> <i>{sample}</i>\n\n"
        "👉 <b>Bước 4/4:</b> Sếp nhập <b>Delay (Số giây)</b> giữa mỗi lần comment:\n"
        "<i>(Khuyên dùng: <code>3</code> hoặc <code>5</code> giây)</i>"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_yt_delay(message: types.Message, delay_str: str):
    user_id = message.from_user.id
    try:
        delay = float(delay_str.strip())
        if delay < 0.5:
            delay = 0.5
    except ValueError:
        bot.send_message(message.chat.id, "❌ Vui lòng nhập số giây hợp lệ (Ví dụ: 3):", reply_markup=get_cancel_keyboard())
        return

    data = user_states[user_id]["data"]
    cookie_str = data["cookie"]
    video_id = data["video_id"]
    video_title = data.get("video_title", video_id)
    messages = data["messages"]
    user_states.pop(user_id, None)

    task_id = generate_task_id("YTB")
    stop_event = threading.Event()
    pause_event = threading.Event()

    task_info = {
        "id": task_id,
        "app": "YouTube",
        "target": f"{video_title[:25]} ({video_id})",
        "status": "running",
        "sent_count": 0,
        "fail_count": 0,
        "last_log": "Đang khởi tạo...",
        "created_at": datetime.now().strftime("%H:%M:%S %d/%m"),
        "stop_event": stop_event,
        "pause_event": pause_event,
        "user_id": user_id
    }
    tasks[task_id] = task_info

    t = threading.Thread(
        target=worker_youtube,
        args=(task_id, cookie_str, video_id, messages, delay),
        daemon=True
    )
    task_info["thread"] = t
    t.start()

    markup = types.InlineKeyboardMarkup()
    markup.add(
        types.InlineKeyboardButton("📋 Xem Quản Lý Task", callback_data="show_tasks"),
        types.InlineKeyboardButton("🛑 Dừng Task Này", callback_data=f"kill_task_{task_id}")
    )

    success_msg = (
        "🚀 <b>ĐÃ KHỞI CHẠY TREO NGÔN YOUTUBE THÀNH CÔNG!</b>\n\n"
        f"🆔 <b>Task ID:</b> <code>{task_id}</code>\n"
        f"🎯 <b>Mục tiêu:</b> {video_title}\n"
        f"⏱️ <b>Delay:</b> {delay}s / comment\n"
        f"📊 <b>Số câu ngôn:</b> {len(messages)} câu\n"
        f"⚡ <b>Trạng thái:</b> 🟢 Đang chạy ngầm\n\n"
        "<i>Sếp có thể bấm Quản Lý Task để theo dõi tiến độ gửi theo thời gian thực!</i>"
    )
    bot.send_message(message.chat.id, success_msg, parse_mode="HTML", reply_markup=markup)

# ==============================================================================
# LUỒNG 2: LOCKET TREO NGÔN
# ==============================================================================

@bot.message_handler(func=lambda m: m.text == "💛 Locket Treo Ngôn")
def start_locket_flow(message: types.Message):
    user_id = message.from_user.id
    if not check_auth(user_id, message.chat.id):
        return

    user_states[user_id] = {"action": "locket_auth", "data": {}}
    text = (
        "💛 <b>THIẾT LẬP TREO NGÔN LOCKET (SPAM KHOẢNH KHẮC WIDGET)</b>\n\n"
        "👉 <b>Bước 1/4:</b> Sếp gửi <b>Tài Khoản Locket</b>:\n"
        "• Dạng: <code>email|mat_khau</code> (Hệ thống tự động đăng nhập Firebase)\n"
        "• Hoặc dạng <b>Token Bearer</b> (<code>Bearer eyJ...</code>)\n\n"
        "<i>Nhập tài khoản vào đây hoặc bấm Hủy bên dưới:</i>"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_locket_auth(message: types.Message, auth_raw: str):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "🔄 Đang xác thực tài khoản Locket, sếp vui lòng chờ giây lát...")

    try:
        client = LocketClient(auth_raw.strip())
        ok, me_res = client.get_self()
        if not ok:
            bot.send_message(
                message.chat.id,
                f"❌ <b>Đăng nhập Locket thất bại!</b>\nLỗi: {me_res}\n\nVui lòng kiểm tra lại email/password hoặc token:",
                parse_mode="HTML",
                reply_markup=get_cancel_keyboard()
            )
            return

        acc_name = me_res.get("display_name") or me_res.get("email") or "Tài khoản Locket"
        my_uid = me_res.get("uid", "")
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Lỗi xử lý tài khoản: {e}", reply_markup=get_cancel_keyboard())
        return

    user_states[user_id]["data"]["auth"] = auth_raw.strip()
    user_states[user_id]["data"]["acc_name"] = acc_name
    user_states[user_id]["action"] = "locket_target"

    text = (
        f"✅ <b>Đăng nhập thành công:</b> <code>{acc_name}</code> (UID: <code>{my_uid}</code>)\n\n"
        "👉 <b>Bước 2/4:</b> Sếp nhập <b>UID Người Nhận</b> trên Locket:\n"
        "• Nhập <b>UID Bạn Bè</b> (Ví dụ: <code>abc123xyz</code>)\n"
        "• Hoặc gõ <code>all</code> để spam tới <b>TẤT CẢ BẠN BÈ</b> trong danh bạ Locket!"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_locket_target(message: types.Message, target_raw: str):
    user_id = message.from_user.id
    target_clean = target_raw.strip()
    if not target_clean:
        bot.send_message(message.chat.id, "❌ Vui lòng nhập UID bạn bè hoặc chữ 'all':", reply_markup=get_cancel_keyboard())
        return

    user_states[user_id]["data"]["target"] = target_clean
    user_states[user_id]["action"] = "locket_msg"

    text = (
        f"🎯 <b>Mục tiêu Locket:</b> <code>{target_clean}</code>\n\n"
        "👉 <b>Bước 3/4:</b> Sếp nhập <b>Nội Dung Ngôn (Caption)</b>:\n"
        "• Gõ câu ngôn trực tiếp vào đây.\n"
        "• Hoặc gửi <b>File .TXT</b> chứa danh sách các câu ngôn để xoay vòng!"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_locket_msg(message: types.Message, msgs: List[str]):
    user_id = message.from_user.id
    user_states[user_id]["data"]["messages"] = msgs
    user_states[user_id]["action"] = "locket_delay"

    sample = msgs[0] if len(msgs) == 1 else f"{len(msgs)} câu ngôn xoay vòng"
    text = (
        f"📝 <b>Đã nhận nội dung:</b> <i>{sample}</i>\n\n"
        "👉 <b>Bước 4/4:</b> Sếp nhập <b>Delay (Số giây)</b> giữa mỗi lần đăng:\n"
        "<i>(Khuyên dùng: <code>2</code> hoặc <code>3</code> giây)</i>"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_locket_delay(message: types.Message, delay_str: str):
    user_id = message.from_user.id
    try:
        delay = float(delay_str.strip())
        if delay < 0.5:
            delay = 0.5
    except ValueError:
        bot.send_message(message.chat.id, "❌ Vui lòng nhập số giây hợp lệ (Ví dụ: 2):", reply_markup=get_cancel_keyboard())
        return

    data = user_states[user_id]["data"]
    auth_str = data["auth"]
    target_uid = data["target"]
    acc_name = data.get("acc_name", "Locket")
    messages = data["messages"]
    user_states.pop(user_id, None)

    task_id = generate_task_id("LOCKET")
    stop_event = threading.Event()
    pause_event = threading.Event()

    task_info = {
        "id": task_id,
        "app": "Locket",
        "target": f"UID: {target_uid} ({acc_name})",
        "status": "running",
        "sent_count": 0,
        "fail_count": 0,
        "last_log": "Đang khởi tạo...",
        "created_at": datetime.now().strftime("%H:%M:%S %d/%m"),
        "stop_event": stop_event,
        "pause_event": pause_event,
        "user_id": user_id
    }
    tasks[task_id] = task_info

    t = threading.Thread(
        target=worker_locket,
        args=(task_id, auth_str, target_uid, messages, delay),
        daemon=True
    )
    task_info["thread"] = t
    t.start()

    markup = types.InlineKeyboardMarkup()
    markup.add(
        types.InlineKeyboardButton("📋 Xem Quản Lý Task", callback_data="show_tasks"),
        types.InlineKeyboardButton("🛑 Dừng Task Này", callback_data=f"kill_task_{task_id}")
    )

    success_msg = (
        "🚀 <b>ĐÃ KHỞI CHẠY TREO NGÔN LOCKET THÀNH CÔNG!</b>\n\n"
        f"🆔 <b>Task ID:</b> <code>{task_id}</code>\n"
        f"🎯 <b>Mục tiêu:</b> <code>{target_uid}</code>\n"
        f"⏱️ <b>Delay:</b> {delay}s / moment\n"
        f"📊 <b>Số câu ngôn:</b> {len(messages)} câu\n"
        f"⚡ <b>Trạng thái:</b> 🟢 Đang chạy ngầm\n\n"
        "<i>Khoảnh khắc widget Locket đang được gửi liên tục!</i>"
    )
    bot.send_message(message.chat.id, success_msg, parse_mode="HTML", reply_markup=markup)

# ==============================================================================
# LUỒNG 3: X (TWITTER) TREO DMS
# ==============================================================================

@bot.message_handler(func=lambda m: m.text == "✖️ X (Twitter) Treo DMs")
def start_x_flow(message: types.Message):
    user_id = message.from_user.id
    if not check_auth(user_id, message.chat.id):
        return

    user_states[user_id] = {"action": "x_cookie", "data": {}}
    text = (
        "✖️ <b>THIẾT LẬP TREO DMS X (TWITTER - TIN NHẮN RIÊNG 1-1)</b>\n\n"
        "👉 <b>Bước 1/4:</b> Sếp gửi <b>Cookie X (Twitter)</b>:\n"
        "• Chuỗi Cookie phải có: <code>auth_token=...</code> và <code>ct0=...</code>\n\n"
        "<i>Dán cookie vào đây hoặc bấm Hủy bên dưới:</i>"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_x_cookie(message: types.Message, cookie_raw: str):
    user_id = message.from_user.id
    cookie_dict = TwitterClient.parse_cookie(cookie_raw)
    if "auth_token" not in cookie_dict or "ct0" not in cookie_dict:
        bot.send_message(
            message.chat.id,
            "❌ <b>Cookie X không hợp lệ!</b> Thiếu <code>auth_token</code> hoặc <code>ct0</code>.\n"
            "Vui lòng copy lại toàn bộ Cookie và gửi lại:",
            parse_mode="HTML",
            reply_markup=get_cancel_keyboard()
        )
        return

    bot.send_message(message.chat.id, "🔄 Đang xác thực tài khoản X...")
    try:
        client = TwitterClient(cookie_raw)
        ok, me = client.get_self()
        if not ok:
            bot.send_message(
                message.chat.id,
                f"❌ <b>Cookie X hết hạn hoặc bị lỗi!</b>\nLỗi: {me}\nVui lòng gửi lại Cookie mới:",
                reply_markup=get_cancel_keyboard()
            )
            return

        x_name = me.get("name") or me.get("screen_name") or "User X"
        x_handle = me.get("screen_name", "")
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Lỗi kiểm tra tài khoản X: {e}", reply_markup=get_cancel_keyboard())
        return

    user_states[user_id]["data"]["cookie"] = cookie_raw
    user_states[user_id]["data"]["x_handle"] = x_handle
    user_states[user_id]["action"] = "x_target"

    text = (
        f"✅ <b>Nhận diện tài khoản:</b> <code>{x_name}</code> (@{x_handle})\n\n"
        "👉 <b>Bước 2/4:</b> Sếp nhập <b>Username (@handle)</b> hoặc <b>UID</b> đối phương cần gửi DMs:\n"
        "<i>(Ví dụ: <code>@elonmusk</code> hoặc <code>elonmusk</code> hoặc ID số <code>44196397</code>)</i>"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_x_target(message: types.Message, target_raw: str):
    user_id = message.from_user.id
    target_clean = target_raw.strip().lstrip("@")
    if not target_clean:
        bot.send_message(message.chat.id, "❌ Vui lòng nhập Username hoặc UID đối phương:", reply_markup=get_cancel_keyboard())
        return

    cookie_raw = user_states[user_id]["data"]["cookie"]
    client = TwitterClient(cookie_raw)

    bot.send_message(message.chat.id, f"🔍 Đang tra cứu thông tin đối phương @{target_clean}...")
    recipient_id = None
    target_display = target_clean

    if target_clean.isdigit():
        recipient_id = target_clean
    else:
        uid, res = client.resolve_screen_name(target_clean)
        if uid:
            recipient_id = uid
            target_display = f"@{target_clean} ({res.get('name', '')})"
        else:
            bot.send_message(
                message.chat.id,
                f"❌ Không tìm thấy người dùng <code>@{target_clean}</code> trên X!\nLỗi: {res}\nVui lòng kiểm tra lại Username:",
                parse_mode="HTML",
                reply_markup=get_cancel_keyboard()
            )
            return

    user_states[user_id]["data"]["recipient_id"] = recipient_id
    user_states[user_id]["data"]["target_display"] = target_display
    user_states[user_id]["action"] = "x_msg"

    text = (
        f"🎯 <b>Mục tiêu nhận DMs:</b> <code>{target_display}</code> (UID: <code>{recipient_id}</code>)\n\n"
        "👉 <b>Bước 3/4:</b> Sếp nhập <b>Nội Dung Ngôn DMs</b>:\n"
        "• Gõ câu ngôn trực tiếp vào đây.\n"
        "• Hoặc gửi <b>File .TXT</b> chứa danh sách các câu ngôn để xoay vòng!"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_x_msg(message: types.Message, msgs: List[str]):
    user_id = message.from_user.id
    user_states[user_id]["data"]["messages"] = msgs
    user_states[user_id]["action"] = "x_delay"

    sample = msgs[0] if len(msgs) == 1 else f"{len(msgs)} câu ngôn xoay vòng"
    text = (
        f"📝 <b>Đã nhận nội dung:</b> <i>{sample}</i>\n\n"
        "👉 <b>Bước 4/4:</b> Sếp nhập <b>Delay (Số giây)</b> giữa mỗi tin nhắn DMs:\n"
        "<i>(Khuyên dùng: <code>3</code> hoặc <code>5</code> giây)</i>"
    )
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


def process_x_delay(message: types.Message, delay_str: str):
    user_id = message.from_user.id
    try:
        delay = float(delay_str.strip())
        if delay < 1.0:
            delay = 1.0
    except ValueError:
        bot.send_message(message.chat.id, "❌ Vui lòng nhập số giây hợp lệ (Ví dụ: 3):", reply_markup=get_cancel_keyboard())
        return

    data = user_states[user_id]["data"]
    cookie_str = data["cookie"]
    recipient_id = data["recipient_id"]
    target_display = data.get("target_display", recipient_id)
    messages = data["messages"]
    user_states.pop(user_id, None)

    task_id = generate_task_id("X_DM")
    stop_event = threading.Event()
    pause_event = threading.Event()

    task_info = {
        "id": task_id,
        "app": "X (Twitter) DMs",
        "target": target_display,
        "status": "running",
        "sent_count": 0,
        "fail_count": 0,
        "last_log": "Đang khởi tạo...",
        "created_at": datetime.now().strftime("%H:%M:%S %d/%m"),
        "stop_event": stop_event,
        "pause_event": pause_event,
        "user_id": user_id
    }
    tasks[task_id] = task_info

    t = threading.Thread(
        target=worker_x,
        args=(task_id, cookie_str, recipient_id, messages, delay),
        daemon=True
    )
    task_info["thread"] = t
    t.start()

    markup = types.InlineKeyboardMarkup()
    markup.add(
        types.InlineKeyboardButton("📋 Xem Quản Lý Task", callback_data="show_tasks"),
        types.InlineKeyboardButton("🛑 Dừng Task Này", callback_data=f"kill_task_{task_id}")
    )

    success_msg = (
        "🚀 <b>ĐÃ KHỞI CHẠY TREO DMS X THÀNH CÔNG!</b>\n\n"
        f"🆔 <b>Task ID:</b> <code>{task_id}</code>\n"
        f"🎯 <b>Mục tiêu:</b> {target_display}\n"
        f"⏱️ <b>Delay:</b> {delay}s / tin nhắn\n"
        f"📊 <b>Số câu ngôn:</b> {len(messages)} câu\n"
        f"⚡ <b>Trạng thái:</b> 🟢 Đang chạy ngầm\n\n"
        "<i>Hộp thư DMs đang được gửi tin nhắn tự động liên tục!</i>"
    )
    bot.send_message(message.chat.id, success_msg, parse_mode="HTML", reply_markup=markup)

# ==============================================================================
# QUẢN LÝ TASK (XEM, TẠM DỪNG, TIẾP TỤC, DỪNG)
# ==============================================================================

@bot.message_handler(commands=['tasks'])
@bot.message_handler(func=lambda m: m.text == "📋 Quản Lý Task")
def handle_view_tasks(message: types.Message):
    user_id = message.from_user.id
    if not check_auth(user_id, message.chat.id):
        return
    render_tasks_menu(message.chat.id)


def render_tasks_menu(chat_id: int, message_id: Optional[int] = None):
    if not tasks:
        text = (
            "📋 <b>DANH SÁCH QUẢN LÝ TASK</b>\n\n"
            "<i>Hiện tại không có task nào đang chạy!</i>\n\n"
            "👉 Hãy chọn <b>YouTube</b>, <b>Locket</b> hoặc <b>X (Twitter)</b> ở menu bên dưới để khởi chạy task mới!"
        )
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔄 Làm Mới", callback_data="refresh_tasks"))
        if message_id:
            try:
                bot.edit_message_text(text, chat_id, message_id, parse_mode="HTML", reply_markup=markup)
            except Exception:
                pass
        else:
            bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=markup)
        return

    active_count = sum(1 for t in tasks.values() if t["status"] in ("running", "paused"))
    text = (
        f"📋 <b>DANH SÁCH QUẢN LÝ TASK ({active_count} task đang mở)</b>\n"
        f"<i>Cập nhật lúc: {datetime.now().strftime('%H:%M:%S')}</i>\n\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    for tid, t in list(tasks.items()):
        status_icon = "🟢" if t["status"] == "running" else ("🟡" if t["status"] == "paused" else "🔴")
        status_text = "Đang chạy" if t["status"] == "running" else ("Tạm dừng" if t["status"] == "paused" else "Đã dừng")

        text += (
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🔹 <b>Task:</b> <code>{tid}</code>\n"
            f"📱 <b>Ứng dụng:</b> {t['app']}\n"
            f"🎯 <b>Mục tiêu:</b> {t['target']}\n"
            f"📊 <b>Tiến độ:</b> ✅ {t['sent_count']} gửi | ❌ {t['fail_count']} lỗi\n"
            f"⚡ <b>Trạng thái:</b> {status_icon} <b>{status_text}</b>\n"
            f"💬 <i>Log: {t['last_log']}</i>\n"
        )

        if t["status"] == "running":
            pause_btn = types.InlineKeyboardButton("⏸️ Tạm Dừng", callback_data=f"pause_task_{tid}")
        elif t["status"] == "paused":
            pause_btn = types.InlineKeyboardButton("▶️ Tiếp Tục", callback_data=f"resume_task_{tid}")
        else:
            pause_btn = types.InlineKeyboardButton("🗑️ Xóa", callback_data=f"del_task_{tid}")

        kill_btn = types.InlineKeyboardButton("🛑 Dừng Hẳn", callback_data=f"kill_task_{tid}")
        markup.add(pause_btn, kill_btn)

    markup.add(
        types.InlineKeyboardButton("🔄 Làm Mới", callback_data="refresh_tasks"),
        types.InlineKeyboardButton("🛑 Dừng Tất Cả Tasks", callback_data="kill_all_tasks")
    )

    if message_id:
        try:
            bot.edit_message_text(text, chat_id, message_id, parse_mode="HTML", reply_markup=markup)
        except Exception:
            pass
    else:
        bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=markup)

# ==============================================================================
# QUẢN LÝ ADMIN (XEM, THÊM XÁC NHẬN, XÓA)
# ==============================================================================

@bot.message_handler(commands=['admin'])
@bot.message_handler(func=lambda m: m.text == "👥 Quản Lý Admin")
def handle_admin_menu(message: types.Message):
    user_id = message.from_user.id
    if not check_auth(user_id, message.chat.id):
        return

    render_admin_menu(message.chat.id)


def render_admin_menu(chat_id: int, message_id: Optional[int] = None):
    text = (
        "👥 <b>DANH SÁCH QUẢN TRỊ VIÊN & HỆ THỐNG THUÊ BOT</b>\n\n"
        f"👑 <b>Admin Master:</b> <code>{config.MASTER_ADMIN_ID}</code> ({config.ADMIN_USERNAME})\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    for adm_id in sorted(list(cached_admins)):
        try:
            chat = bot.get_chat(adm_id)
            name = f"{chat.first_name} {chat.last_name or ''}".strip()
            username = f"@{chat.username}" if chat.username else "Không có username"
        except Exception:
            name = "Người dùng Telegram"
            username = "N/A"

        role = "👑 Master Admin" if adm_id == config.MASTER_ADMIN_ID else "🛡️ Admin Phụ"
        text += (
            f"🔹 <b>{role}:</b>\n"
            f"   • Tên: <b>{name}</b>\n"
            f"   • Username: {username}\n"
            f"   • UID: <code>{adm_id}</code>\n"
        )
        if adm_id != config.MASTER_ADMIN_ID:
            markup.add(types.InlineKeyboardButton(f"🗑️ Xóa Admin: {name[:12]} ({adm_id})", callback_data=f"del_admin_{adm_id}"))

    text += "\n<i>Sếp có thể thêm Admin phụ bằng cách bấm nút bên dưới:</i>"
    markup.add(
        types.InlineKeyboardButton("➕ Thêm Admin Phụ", callback_data="add_admin_prompt"),
        types.InlineKeyboardButton("🔄 Làm Mới", callback_data="refresh_admins")
    )

    if message_id:
        try:
            bot.edit_message_text(text, chat_id, message_id, parse_mode="HTML", reply_markup=markup)
        except Exception:
            pass
    else:
        bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=markup)

# ==============================================================================
# XỬ LÝ DOCUMENT (FILE TXT)
# ==============================================================================

@bot.message_handler(content_types=['document'])
def handle_document(message: types.Message):
    user_id = message.from_user.id
    if not check_auth(user_id, message.chat.id):
        return

    state = user_states.get(user_id)
    if not state:
        bot.send_message(message.chat.id, "💡 Sếp vui lòng chọn chức năng trước khi gửi file!", reply_markup=get_main_keyboard())
        return

    action = state.get("action")
    if action in ("yt_msg", "locket_msg", "x_msg"):
        try:
            file_info = bot.get_file(message.document.file_id)
            downloaded = bot.download_file(file_info.file_path)
            content = downloaded.decode('utf-8', errors='ignore')
            lines = [line.strip() for line in content.splitlines() if line.strip()]
            if not lines:
                bot.send_message(message.chat.id, "❌ File không có nội dung hợp lệ! Vui lòng kiểm tra lại:", reply_markup=get_cancel_keyboard())
                return

            bot.send_message(message.chat.id, f"📁 Đã đọc thành công <b>{len(lines)}</b> câu ngôn từ file <code>{message.document.file_name}</code>!", parse_mode="HTML")

            if action == "yt_msg":
                process_yt_msg(message, lines)
            elif action == "locket_msg":
                process_locket_msg(message, lines)
            elif action == "x_msg":
                process_x_msg(message, lines)
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Lỗi khi đọc file: {e}", reply_markup=get_cancel_keyboard())
    else:
        bot.send_message(message.chat.id, "💡 Hiện tại không yêu cầu gửi file. Sếp vui lòng nhập nội dung theo hướng dẫn!", reply_markup=get_cancel_keyboard())

# ==============================================================================
# XỬ LÝ TEXT INPUT THEO STATE MACHINE
# ==============================================================================

@bot.message_handler(func=lambda m: True)
def handle_all_text(message: types.Message):
    user_id = message.from_user.id
    if not check_auth(user_id, message.chat.id):
        return

    text = message.text.strip()
    state = user_states.get(user_id)
    if not state:
        # Nếu không có state, chỉ phản hồi menu chính
        return

    action = state.get("action")

    # YouTube Steps
    if action == "yt_cookie":
        process_yt_cookie(message, text)
    elif action == "yt_target":
        process_yt_target(message, text)
    elif action == "yt_msg":
        process_yt_msg(message, [text])
    elif action == "yt_delay":
        process_yt_delay(message, text)

    # Locket Steps
    elif action == "locket_auth":
        process_locket_auth(message, text)
    elif action == "locket_target":
        process_locket_target(message, text)
    elif action == "locket_msg":
        process_locket_msg(message, [text])
    elif action == "locket_delay":
        process_locket_delay(message, text)

    # X (Twitter) Steps
    elif action == "x_cookie":
        process_x_cookie(message, text)
    elif action == "x_target":
        process_x_target(message, text)
    elif action == "x_msg":
        process_x_msg(message, [text])
    elif action == "x_delay":
        process_x_delay(message, text)

    # Thêm Admin Steps
    elif action == "input_admin_id":
        process_input_admin_id(message, text)

# ==============================================================================
# XỬ LÝ THÊM ADMIN VỚI XÁC NHẬN THÔNG TIN ĐẦY ĐỦ
# ==============================================================================

def process_input_admin_id(message: types.Message, text: str):
    user_id = message.from_user.id
    try:
        new_uid = int(text.strip())
    except ValueError:
        bot.send_message(message.chat.id, "❌ ID Telegram phải là một dãy số nguyên! Vui lòng nhập lại:", reply_markup=get_cancel_keyboard())
        return

    if new_uid in cached_admins:
        bot.send_message(message.chat.id, f"⚠️ Người dùng <code>{new_uid}</code> đã là Admin từ trước!", parse_mode="HTML", reply_markup=get_main_keyboard())
        user_states.pop(user_id, None)
        return

    bot.send_message(message.chat.id, f"🔍 Đang kiểm tra thông tin tài khoản Telegram ID <code>{new_uid}</code>...", parse_mode="HTML")
    try:
        chat = bot.get_chat(new_uid)
        full_name = f"{chat.first_name} {chat.last_name or ''}".strip()
        username = f"@{chat.username}" if chat.username else "Không có username"
    except Exception as e:
        full_name = "Không xác định (User chưa từng nhắn bot)"
        username = "N/A"

    user_states[user_id] = {
        "action": "confirm_add_admin",
        "pending_uid": new_uid,
        "pending_name": full_name,
        "pending_username": username
    }

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("✅ Xác Nhận Thêm", callback_data=f"confirm_add_{new_uid}"),
        types.InlineKeyboardButton("❌ Hủy Bỏ", callback_data="cancel_action")
    )

    confirm_text = (
        "👤 <b>XÁC NHẬN CẤP QUYỀN ADMIN CHO NGƯỜI DÙNG:</b>\n\n"
        f"🆔 <b>Telegram UID:</b> <code>{new_uid}</code>\n"
        f"📛 <b>Họ và tên:</b> <b>{full_name}</b>\n"
        f"🔗 <b>Username:</b> {username}\n\n"
        "❓ <i>Sếp có chắc chắn muốn cấp toàn bộ quyền sử dụng bot cho tài khoản này không?</i>"
    )
    bot.send_message(message.chat.id, confirm_text, parse_mode="HTML", reply_markup=markup)

# ==============================================================================
# CALLBACK QUERY HANDLER
# ==============================================================================

@bot.callback_query_handler(func=lambda call: True)
def handle_callback_query(call: types.CallbackQuery):
    user_id = call.from_user.id
    if not check_auth(user_id, call.message.chat.id if call.message else None):
        bot.answer_callback_query(call.id, "⛔ Bạn chưa được cấp quyền sử dụng bot!", show_alert=True)
        return

    data = call.data
    chat_id = call.message.chat.id

    if data == "cancel_action":
        user_states.pop(user_id, None)
        bot.answer_callback_query(call.id, "Đã hủy thao tác!")
        try:
            bot.edit_message_text("✅ Đã hủy thao tác hiện tại!", chat_id, call.message.message_id)
        except Exception:
            pass

    elif data == "show_tasks" or data == "refresh_tasks":
        bot.answer_callback_query(call.id, "Đã cập nhật danh sách task!")
        render_tasks_menu(chat_id, call.message.message_id)

    elif data.startswith("pause_task_"):
        tid = data.replace("pause_task_", "")
        if tid in tasks:
            tasks[tid]["pause_event"].set()
            tasks[tid]["status"] = "paused"
            bot.answer_callback_query(call.id, f"Đã tạm dừng task {tid}!")
        render_tasks_menu(chat_id, call.message.message_id)

    elif data.startswith("resume_task_"):
        tid = data.replace("resume_task_", "")
        if tid in tasks:
            tasks[tid]["pause_event"].clear()
            tasks[tid]["status"] = "running"
            bot.answer_callback_query(call.id, f"Đã tiếp tục task {tid}!")
        render_tasks_menu(chat_id, call.message.message_id)

    elif data.startswith("kill_task_"):
        tid = data.replace("kill_task_", "")
        if tid in tasks:
            tasks[tid]["stop_event"].set()
            tasks[tid]["status"] = "stopped"
            bot.answer_callback_query(call.id, f"Đã dừng task {tid}!")
        render_tasks_menu(chat_id, call.message.message_id)

    elif data.startswith("del_task_"):
        tid = data.replace("del_task_", "")
        if tid in tasks:
            tasks[tid]["stop_event"].set()
            tasks.pop(tid, None)
            bot.answer_callback_query(call.id, f"Đã xóa task {tid}!")
        render_tasks_menu(chat_id, call.message.message_id)

    elif data == "kill_all_tasks":
        for t in tasks.values():
            t["stop_event"].set()
            t["status"] = "stopped"
        bot.answer_callback_query(call.id, "Đã dừng tất cả các task đang chạy!", show_alert=True)
        render_tasks_menu(chat_id, call.message.message_id)

    elif data == "refresh_admins":
        bot.answer_callback_query(call.id, "Đã làm mới danh sách Admin!")
        render_admin_menu(chat_id, call.message.message_id)

    elif data == "add_admin_prompt":
        user_states[user_id] = {"action": "input_admin_id"}
        bot.answer_callback_query(call.id)
        prompt_text = (
            "➕ <b>THÊM QUẢN TRỊ VIÊN / KHÁCH THUÊ BOT</b>\n\n"
            "👉 Sếp vui lòng nhập <b>Telegram ID</b> (UID) của người cần cấp quyền:\n"
            "<i>(Ví dụ: <code>1234567890</code>)</i>"
        )
        bot.send_message(chat_id, prompt_text, parse_mode="HTML", reply_markup=get_cancel_keyboard())

    elif data.startswith("confirm_add_"):
        new_uid = int(data.replace("confirm_add_", ""))
        cached_admins.add(new_uid)
        save_admins()
        user_states.pop(user_id, None)
        bot.answer_callback_query(call.id, f"Đã thêm thành công Admin {new_uid}!", show_alert=True)
        try:
            bot.edit_message_text(f"🎉 <b>Đã cấp quyền thành công cho Admin ID:</b> <code>{new_uid}</code>!", chat_id, call.message.message_id, parse_mode="HTML")
        except Exception:
            pass
        render_admin_menu(chat_id)

    elif data.startswith("del_admin_"):
        target_uid = int(data.replace("del_admin_", ""))
        if target_uid == config.MASTER_ADMIN_ID:
            bot.answer_callback_query(call.id, "Không thể xóa Master Admin!", show_alert=True)
            return
        if target_uid in cached_admins:
            cached_admins.remove(target_uid)
            save_admins()
            bot.answer_callback_query(call.id, f"Đã xóa quyền Admin của {target_uid}!", show_alert=True)
        render_admin_menu(chat_id, call.message.message_id)

# ==============================================================================
# HÀM KHỞI CHẠY CHÍNH
# ==============================================================================
def main():
    logger.info("==================================================")
    logger.info("  BOT 3 APPS MINI (YTB, LOCKET, X) ĐANG KHỞI ĐỘNG  ")
    logger.info(f"  Master Admin ID: {config.MASTER_ADMIN_ID}")
    logger.info(f"  Admin Contact: {config.ADMIN_CONTACT_URL}")
    logger.info("==================================================")
    try:
        bot.infinity_polling(timeout=20, long_polling_timeout=15)
    except Exception as e:
        logger.error(f"Lỗi polling bot: {e}")
        time.sleep(3)

if __name__ == "__main__":
    main()
