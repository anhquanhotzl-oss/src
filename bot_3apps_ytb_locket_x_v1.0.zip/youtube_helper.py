# -*- coding: utf-8 -*-
"""
Module YouTube Helper chuyên dụng cho Treo Ngôn Bình Luận Video / Live Stream YouTube.
Sử dụng InnerTube API & SAPISIDHASH authentication.
"""

import re
import os
import sys
import time
import json
import random
import string
import hashlib
import requests
from typing import Tuple, Dict, Any, Optional

DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"

def parse_and_clean_cookie(raw: str) -> str:
    """Chuẩn hóa chuỗi cookie từ các định dạng khác nhau."""
    if not raw:
        return ""
    raw = raw.strip()
    if raw.startswith("[") and raw.endswith("]"):
        try:
            arr = json.loads(raw)
            parts = []
            for item in arr:
                name = item.get("name")
                val = item.get("value")
                if name and val is not None:
                    parts.append(f"{name}={val}")
            return "; ".join(parts)
        except Exception:
            pass
    return raw

def extract_yt_sapisid(cookie_str: str) -> str:
    """Trích xuất SAPISID hoặc __Secure-3PAPISID từ Cookie."""
    clean = parse_and_clean_cookie(cookie_str)
    for part in clean.split(";"):
        part = part.strip()
        if part.startswith("SAPISID="):
            return part.split("=", 1)[1]
        elif part.startswith("__Secure-3PAPISID="):
            return part.split("=", 1)[1]
    return ""

def get_yt_auth_header(sapisid: str) -> str:
    """Tạo header Authorization SAPISIDHASH theo chuẩn InnerTube."""
    t = str(int(time.time()))
    payload = f"{t} {sapisid} https://www.youtube.com"
    h = hashlib.sha1(payload.encode()).hexdigest()
    return f"SAPISIDHASH {t}_{h}"

def parse_yt_video_id(target: str) -> str:
    """Trích xuất Video ID từ link YouTube hoặc chuỗi ID thuần."""
    target = target.strip()
    # Các định dạng link YouTube phổ biến
    m = re.search(r'(?:v=|\/live\/|\/shorts\/|youtu\.be\/|embed\/)([a-zA-Z0-9_-]{11})', target)
    if m:
        return m.group(1)
    if len(target) == 11 and re.match(r'^[a-zA-Z0-9_-]{11}$', target):
        return target
    return target

def get_yt_video_info(video_id: str) -> Dict[str, Any]:
    """Lấy tiêu đề và thông tin chủ sở hữu video YouTube."""
    clean_id = parse_yt_video_id(video_id)
    headers = {
        "User-Agent": DEFAULT_USER_AGENT,
        "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
    }
    try:
        r = requests.get(f"https://www.youtube.com/watch?v={clean_id}", headers=headers, timeout=10)
        title_m = re.search(r'<title>(.*?)</title>', r.text)
        title = title_m.group(1).replace(" - YouTube", "").strip() if title_m else f"Video {clean_id}"
        owner_m = re.search(r'"ownerChannelName":"([^"]+)"', r.text)
        if not owner_m:
            owner_m = re.search(r'"author":"([^"]+)"', r.text)
        owner = owner_m.group(1) if owner_m else "Kênh YouTube"
        return {"video_id": clean_id, "title": title, "owner": owner, "valid": True}
    except Exception:
        return {"video_id": clean_id, "title": f"Video {clean_id}", "owner": "Không rõ", "valid": True}

def get_yt_account_info(cookie_str: str) -> Dict[str, Any]:
    """Kiểm tra Cookie YouTube và lấy tên kênh / người dùng."""
    clean = parse_and_clean_cookie(cookie_str)
    sapisid = extract_yt_sapisid(clean)
    if not sapisid:
        return {"name": "Không xác định", "valid": False, "error": "Thiếu SAPISID trong Cookie"}

    auth_header = get_yt_auth_header(sapisid)
    headers = {
        "User-Agent": DEFAULT_USER_AGENT,
        "Accept-Language": "vi-VN,vi;q=0.9",
        "Authorization": auth_header,
        "X-Goog-AuthUser": "0",
        "Cookie": clean
    }
    try:
        r = requests.get("https://www.youtube.com", headers=headers, timeout=10)
        m = re.search(r'"channelTitle":"([^"]+)"', r.text)
        if not m:
            m = re.search(r'"title":"([^"]+)","endpoint"', r.text)
        name = m.group(1) if m else f"YT_User_{sapisid[:6]}"
        return {"name": name, "valid": True, "sapisid": sapisid}
    except Exception:
        return {"name": f"YT_User_{sapisid[:6]}", "valid": True, "sapisid": sapisid}

def get_yt_comment_params(session: requests.Session, video_id: str, cookie_str: str, sapisid: str) -> Tuple[str, str, Optional[str]]:
    """Lấy InnerTube API Key, Client Version và createCommentParams."""
    clean_id = parse_yt_video_id(video_id)
    auth_header = get_yt_auth_header(sapisid)
    headers = {
        "User-Agent": DEFAULT_USER_AGENT,
        "Accept-Language": "vi-VN,vi;q=0.9",
        "Authorization": auth_header,
        "X-Origin": "https://www.youtube.com",
        "Origin": "https://www.youtube.com",
        "X-Goog-AuthUser": "0",
        "Cookie": cookie_str
    }
    r = session.get(f"https://www.youtube.com/watch?v={clean_id}", headers=headers, timeout=15)

    key_match = re.search(r'"INNERTUBE_API_KEY":"([^"]+)"', r.text)
    api_key = key_match.group(1) if key_match else "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"

    ver_match = re.search(r'"INNERTUBE_CLIENT_VERSION":"([^"]+)"', r.text)
    client_ver = ver_match.group(1) if ver_match else "2.20261027.01.00"

    direct_match = re.search(r'"createCommentParams"\s*:\s*"([^"]+)"', r.text)
    if direct_match:
        return api_key, client_ver, direct_match.group(1)

    token = None
    match = re.search(r'var ytInitialData = ({.*?});</script>', r.text)
    if not match:
        match = re.search(r'ytInitialData\s*=\s*({.*?});', r.text)
    if match:
        try:
            data = json.loads(match.group(1))
            contents = data.get("contents", {}).get("twoColumnWatchNextResults", {}).get("results", {}).get("results", {}).get("contents", [])
            for item in contents:
                sec = item.get("itemSectionRenderer", {})
                if sec.get("targetId") == "comments-section":
                    for c in sec.get("contents", []):
                        token = c.get("continuationItemRenderer", {}).get("continuationEndpoint", {}).get("continuationCommand", {}).get("token")
                        if token:
                            break
        except Exception:
            pass

    create_params = None
    if token and api_key:
        next_url = f"https://www.youtube.com/youtubei/v1/next?key={api_key}"
        payload = {
            "context": {
                "client": {"clientName": "WEB", "clientVersion": client_ver, "hl": "vi", "gl": "VN"}
            },
            "continuation": token
        }
        r2 = session.post(next_url, headers=headers, json=payload, timeout=15)
        m2 = re.search(r'"createCommentParams"\s*:\s*"([^"]+)"', r2.text)
        if m2:
            create_params = m2.group(1)

    return api_key, client_ver, create_params

def send_yt_comment(session: requests.Session, api_key: str, client_ver: str, create_params: str, cookie_str: str, sapisid: str, comment_text: str) -> Tuple[bool, str]:
    """Gửi bình luận vào video / live stream YouTube."""
    auth_header = get_yt_auth_header(sapisid)
    url = f"https://www.youtube.com/youtubei/v1/comment/create_comment?key={api_key}&prettyPrint=false"
    headers = {
        "User-Agent": DEFAULT_USER_AGENT,
        "Content-Type": "application/json",
        "X-Origin": "https://www.youtube.com",
        "Origin": "https://www.youtube.com",
        "Authorization": auth_header,
        "X-Goog-AuthUser": "0",
        "Cookie": cookie_str
    }
    payload = {
        "context": {
            "client": {"clientName": "WEB", "clientVersion": client_ver, "hl": "vi", "gl": "VN"}
        },
        "commentText": comment_text,
        "createCommentParams": create_params
    }
    try:
        res = session.post(url, headers=headers, json=payload, timeout=20)
        if "showErrorAction" in res.text:
            return False, res.text
        return True, "OK"
    except Exception as e:
        return False, str(e)
