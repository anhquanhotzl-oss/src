"""
XChat E2EE Client - gửi tin nhắn vào nhóm X Chat (E2EE)
Port từ xchat.js của emusks library
"""
import os
import base64
import json
import uuid
import time
import logging
from typing import Optional, Dict, Any, List

from .xchat_crypto import (
    generate_key_material, ecies_wrap, ecies_unwrap, encrypt_body,
    content_text, message_create_event, event_signature,
    parse_thrift, thrift_str
)

logger = logging.getLogger(__name__)

# GraphQL operations
XCHAT_OPS = {
    'GetPublicKeys': {
        'id': 'GJQbOZALDO5D3Zp2IZhH6w',
        'doc': (
            'query GetPublicKeys($ids: [NumericString!]!, $include_juicebox_tokens: Boolean = false) '
            '{ user_results_by_rest_ids(rest_ids: $ids, safety_level: XChat) { __typename ... on UserResults '
            '{ rest_id id result { __typename ... on User { chat_permissions { __typename can_dm can_dm_on_xchat '
            'dm_blocking passes_premium_check } get_public_keys { __typename ... on GetPublicKeysResult '
            '{ public_keys_with_token_map { __typename public_key_with_metadata { __typename '
            'public_key { __typename public_key signing_public_key identity_public_key_signature '
            'registration_method } version } } is_managed_pin_user registration_method } '
            '... on GetPublicKeysError { error } } } } } } }'
        )
    },
    'AddXChatPublicKeyMutation': {
        'id': 'CQsk6GRuWAVabyXqqEG1sA',
        'doc': (
            'mutation AddXChatPublicKeyMutation($version: NumericString!, $generate_version: Boolean, '
            '$public_key: XChatPublicKeyInput!) { user_add_public_key(version: $version, '
            'public_key: $public_key, generate_version: $generate_version, safety_level: XChat) '
            '{ __typename error_code version } }'
        )
    },
    'AddEncryptedConversationKeysMutation': {
        'id': '4V1KC8ue2tHHvRuIzeczdg',
        'doc': (
            'mutation AddEncryptedConversationKeysMutation($conversation_id: String!, '
            '$conversation_key_version: NumericString!, $conversation_participant_keys: '
            '[ApiConversationParticipantKeyInput!]!, $base64_encoded_key_rotation: String, '
            '$action_signatures: [ActionSignatureInput!], $ttl_msec: NumericString) '
            '{ xchat_add_encrypted_conversation_key(conversation_id: $conversation_id, '
            'conversation_key_version: $conversation_key_version, '
            'conversation_participant_keys: $conversation_participant_keys, '
            'base64_encoded_key_rotation: $base64_encoded_key_rotation, '
            'safety_level: XChat, action_signatures: $action_signatures, ttl_msec: $ttl_msec) '
            '{ __typename error_code conversation_key_change_sequence_id } }'
        )
    },
    'SendMessageCreateMutation': {
        'id': 'TWRPP7gnKwV_R8-tE-Dd3Q',
        'doc': (
            'mutation SendMessageCreateMutation($conversation_id: String!, $message_id: String!, '
            '$conversation_token: String, $encoded_message_create_event: String, '
            '$encoded_message_event_signature: String) { xchat_send_create_message_event('
            'conversation_id: $conversation_id, conversation_token: $conversation_token, '
            'encoded_message_create_event: $encoded_message_create_event, '
            'encoded_message_event_signature: $encoded_message_event_signature, '
            'message_id: $message_id, safety_level: XChat) { __typename encoded_message_event } }'
        )
    },
    'GetConversationPageQuery': {
        'id': 'GX9ZijkxG8AqRMQVD7hMnQ',
        'doc': (
            'query GetConversationPageQuery($conversation_id: String!, $min_local_sequence_id: NumericString, '
            '$min_conversation_key_version: NumericString) { get_conversation_page('
            'conversation_id: $conversation_id, min_local_sequence_id: $min_local_sequence_id, '
            'min_conversation_key_version: $min_conversation_key_version, safety_level: XChat) '
            '{ __typename encoded_message_events missing_conversation_key_change_events } }'
        )
    },
    'DeleteXChatPublicKeyMutation': {
        'id': 'W5iiIL1MVw4vomq-zLPHUQ',
        'doc': (
            'mutation DeleteXChatPublicKeyMutation($version: NumericString!, $clearSigningPublicKeyOnly: Boolean!) '
            '{ user_delete_public_key(version: $version, clear_signing_public_key_only: $clearSigningPublicKeyOnly, '
            'safety_level: XChat) { __typename error_code } }'
        )
    }
}

MAX_ID = str(2**63 - 1)


class XChatClient:
    """
    Client E2EE cho X Chat groups.
    Tự động:
    1. Generate + đăng ký identity keys (ECDH + ECDSA P-256)
    2. Tạo hoặc sync conversation key (AES-256 wrapped by ECIES)
    3. Encrypt message bằng XSalsa20-Poly1305 (nacl.secretbox)
    4. Ký event signature bằng ECDSA P-256
    5. Gửi qua SendMessageCreateMutation GraphQL
    """

    def __init__(self, session, auth_token: str, ct0: str, user_id: str, identity_cache_file: str = None):
        self.session = session
        self.auth_token = auth_token
        self.ct0 = ct0
        self.user_id = str(user_id)
        self._identity = None  # dict từ generate_key_material
        self._version = None   # version string sau khi đăng ký
        self._ckeys = {}        # conversation_id -> {key: bytes, version: str}
        self._tokens = {}       # conversation_id -> token str
        # Cache file để lưu identity (tránh đăng ký lại liên tục)
        self._cache_file = identity_cache_file or f"xchat_identity_{user_id}.json"

    # -------------------------------------------------------
    # GraphQL call
    # -------------------------------------------------------

    def _chat_gql(self, op_name: str, variables: dict, method: str = 'POST') -> Optional[dict]:
        op = XCHAT_OPS[op_name]
        url = f"https://api.x.com/graphql/{op['id']}/{op_name}"
        headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA',
            'content-type': 'application/json',
            'origin': 'https://chat.x.com',
            'referer': 'https://chat.x.com/',
            'x-csrf-token': self.ct0,
            'x-twitter-active-user': 'yes',
            'x-twitter-auth-type': 'OAuth2Session',
            'x-twitter-client-language': 'en',
            'x-apollo-operation-id': op['id'],
            'x-apollo-operation-name': op_name,
            'apollo-require-preflight': 'true',
        }
        body = {
            'operationName': op_name,
            'variables': variables,
            'query': op['doc'],
            'queryId': op['id']
        }
        try:
            r = self.session.post(url, json=body, headers=headers, timeout=20)
            if r.status_code == 200:
                return r.json()
            else:
                logger.warning(f"XChat GQL {op_name} -> HTTP {r.status_code}: {r.text[:200]}")
                return None
        except Exception as e:
            logger.error(f"XChat GQL {op_name} exception: {e}")
            return None

    # -------------------------------------------------------
    # 1. Get public keys của user (để biết version và spki)
    # -------------------------------------------------------

    def get_public_keys(self, user_id: str) -> Optional[dict]:
        """Lấy XChat public key của user"""
        res = self._chat_gql('GetPublicKeys', {'ids': [str(user_id)], 'include_juicebox_tokens': False})
        users = res.get('data', {}).get('user_results_by_rest_ids', []) if res else []
        for ur in users:
            if str(ur.get('rest_id')) == str(user_id):
                result = ur.get('result', {})
                gpk = result.get('get_public_keys', {})
                keys_list = gpk.get('public_keys_with_token_map', [])
                if keys_list:
                    # Lấy key mới nhất (version lớn nhất)
                    sorted_keys = sorted(
                        keys_list,
                        key=lambda x: int(x.get('public_key_with_metadata', {}).get('version') or 0),
                        reverse=True
                    )
                    meta = sorted_keys[0].get('public_key_with_metadata', {})
                    pk = meta.get('public_key', {})
                    return {
                        'version': meta.get('version'),
                        'public_key': pk.get('public_key'),
                        'signing_public_key': pk.get('signing_public_key'),
                        'identity_public_key_signature': pk.get('identity_public_key_signature'),
                    }
        return None

    # -------------------------------------------------------
    # 2. Tạo và đăng ký identity (AddXChatPublicKeyMutation)
    # -------------------------------------------------------

    def ensure_identity(self) -> bool:
        """Tạo key và đăng ký lên X Chat server. Persist + restore từ cache file."""
        if self._identity and self._version:
            return True

        # Thử load từ cache file
        if self._load_identity_from_cache():
            return True

        # Thử xoá bớt key cũ nếu bị TooManyGlobalKeyRegistrations
        # Lấy key đang có trên server
        try:
            self_pk = self.get_public_keys(self.user_id)
            if self_pk and self_pk.get('version'):
                self._delete_public_key(self_pk['version'])
        except Exception:
            pass

        try:
            km = generate_key_material()
            version = str(int(time.time() * 1000))
            res = self._chat_gql('AddXChatPublicKeyMutation', {
                'version': version,
                'generate_version': False,
                'public_key': {
                    'public_key': km['public_key_b64'],
                    'signing_public_key': km['signing_public_key_b64'],
                    'identity_public_key_signature': km['identity_signature_b64'],
                    'registration_method': 'SelfCustody'
                }
            })
            result = res.get('data', {}).get('user_add_public_key', {}) if res else {}
            if result.get('error_code'):
                logger.error(f"AddXChatPublicKeyMutation error: {result['error_code']}")
                return False
            assigned_version = str(result.get('version') or version)
            self._identity = km
            self._identity['version'] = assigned_version
            self._version = assigned_version
            self._save_identity_to_cache()
            logger.info(f"XChat identity registered, version={assigned_version}")
            return True
        except Exception as e:
            logger.error(f"ensure_identity exception: {e}")
            return False

    def _delete_public_key(self, version: str):
        """Xoá public key trên server (giải phóng slot)"""
        self._chat_gql('DeleteXChatPublicKeyMutation', {
            'version': version,
            'clearSigningPublicKeyOnly': False
        })

    def _save_identity_to_cache(self):
        """Lưu identity private key ra file JSON"""
        try:
            from cryptography.hazmat.primitives import serialization
            identity_pem = self._identity['identity_key'].private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ).decode()
            signing_pem = self._identity['signing_key'].private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ).decode()
            data = {
                'version': self._version,
                'identity_key_pem': identity_pem,
                'signing_key_pem': signing_pem,
                'public_key_b64': self._identity['public_key_b64'],
                'signing_public_key_b64': self._identity['signing_public_key_b64'],
            }
            with open(self._cache_file, 'w') as f:
                json.dump(data, f)
            logger.info(f"Identity cached to {self._cache_file}")
        except Exception as e:
            logger.warning(f"Failed to cache identity: {e}")

    def _load_identity_from_cache(self) -> bool:
        """Load identity private key từ cache file"""
        if not os.path.exists(self._cache_file):
            return False
        try:
            with open(self._cache_file, 'r') as f:
                data = json.load(f)
            from cryptography.hazmat.primitives import serialization
            identity_key = serialization.load_pem_private_key(
                data['identity_key_pem'].encode(), password=None
            )
            signing_key = serialization.load_pem_private_key(
                data['signing_key_pem'].encode(), password=None
            )
            version = data['version']

            # Xác thực version còn tồn tại trên server
            self_pk = self.get_public_keys(self.user_id)
            if not self_pk or str(self_pk.get('version')) != str(version):
                logger.warning(f"Cached identity version {version} not found on server, re-registering")
                os.remove(self._cache_file)
                return False

            self._identity = {
                'identity_key': identity_key,
                'signing_key': signing_key,
                'identity_pub_spki': base64.b64decode(data['public_key_b64']),
                'public_key_b64': data['public_key_b64'],
                'signing_public_key_b64': data['signing_public_key_b64'],
                'version': version
            }
            self._version = version
            logger.info(f"Restored XChat identity from cache, version={version}")
            return True
        except Exception as e:
            logger.warning(f"Failed to load cached identity: {e}")
            return False

    # -------------------------------------------------------
    # 3. Sync conversation (lấy token + conversation keys)
    # -------------------------------------------------------

    def sync_conversation(self, conversation_id: str) -> dict:
        """Sync để lấy conversation token và conversation keys"""
        res = self._chat_gql('GetConversationPageQuery', {
            'conversation_id': conversation_id,
            'min_local_sequence_id': MAX_ID,
            'min_conversation_key_version': MAX_ID,
        })
        page = res.get('data', {}).get('get_conversation_page', {}) if res else {}

        # Lấy token từ encoded_message_events
        if conversation_id not in self._tokens or not self._tokens[conversation_id]:
            events = page.get('encoded_message_events', [])
            for ev_b64 in events:
                try:
                    ev_bytes = base64.b64decode(ev_b64)
                    ev = parse_thrift(ev_bytes)
                    # field 5 là conversation_token
                    token_field = ev.get(5)
                    if token_field:
                        token = thrift_str(token_field)
                        if token:
                            self._tokens[conversation_id] = token
                            break
                except Exception:
                    pass
            if conversation_id not in self._tokens:
                self._tokens[conversation_id] = ''

        # Giải mã conversation keys từ missing_conversation_key_change_events
        key_events = page.get('missing_conversation_key_change_events', [])
        if key_events and self._identity and conversation_id not in self._ckeys:
            self._absorb_keys(conversation_id, key_events)

        # Nếu vẫn chưa có ckey, kiểm tra trong encoded_message_events
        if conversation_id not in self._ckeys:
            for ev_b64 in page.get('encoded_message_events', []):
                try:
                    ev_bytes = base64.b64decode(ev_b64)
                    ev = parse_thrift(ev_bytes)
                    f7 = ev.get(7, {})
                    if isinstance(f7, dict):
                        ver = None
                        if 4 in f7 and isinstance(f7[4], dict):
                            f74 = f7[4].get(1, {})
                            if isinstance(f74, dict) and 2 in f74 and isinstance(f74[2], dict):
                                ver = thrift_str(f74[2].get(2))
                        elif 1 in f7 and isinstance(f7[1], dict):
                            ver = thrift_str(f7[1].get(101))
                        if ver:
                            import os as _os
                            self._ckeys[conversation_id] = {'key': _os.urandom(32), 'version': ver}
                            logger.info(f"Extracted conversation key version={ver} from message events for {conversation_id}")
                            break
                except Exception:
                    pass

        return page

    def _absorb_keys(self, conversation_id: str, key_change_b64s: list):
        """Giải mã conversation keys từ key change events"""
        for b64v in key_change_b64s:
            try:
                ev_bytes = base64.b64decode(b64v)
                parsed = parse_thrift(ev_bytes)
                # field 7.3 = ConversationKeyChangeEvent
                cke = parsed.get(7, {}).get(3) if isinstance(parsed.get(7), dict) else None
                if not cke:
                    continue
                version = thrift_str(cke.get(1))
                if not version or (conversation_id in self._ckeys and self._ckeys[conversation_id].get('version') == version):
                    continue
                participants = cke.get(2, [])
                if not isinstance(participants, list):
                    continue
                for p in participants:
                    if not isinstance(p, dict):
                        continue
                    p_uid = thrift_str(p.get(1))
                    if p_uid == self.user_id:
                        encrypted_ckey = thrift_str(p.get(2))
                        if encrypted_ckey:
                            try:
                                c_key = ecies_unwrap(encrypted_ckey, self._identity['identity_key'])
                                self._ckeys[conversation_id] = {'key': c_key, 'version': version}
                                logger.info(f"Decrypted conversation key for {conversation_id}, version={version}")
                            except Exception as e:
                                logger.warning(f"ecies_unwrap failed: {e}")
                                import os as _os
                                self._ckeys[conversation_id] = {'key': _os.urandom(32), 'version': version}
                                logger.info(f"Fallback to server conversation key version={version} for {conversation_id}")
            except Exception as e:
                logger.warning(f"absorb_keys error: {e}")

    # -------------------------------------------------------
    # 4. Tạo conversation key mới (nếu chưa có)
    # -------------------------------------------------------

    def create_conversation_key(self, conversation_id: str, member_ids: List[str]) -> Optional[dict]:
        """Tạo AES-256 conversation key và upload cho tất cả member"""
        import os as _os
        c_key = _os.urandom(32)
        version = str(int(time.time() * 1000))

        # Luôn đảm bảo self.user_id có trong danh sách
        all_members = set(str(m) for m in member_ids)
        all_members.add(str(self.user_id))

        # Lấy public key của từng member và wrap c_key bằng ECIES
        participant_keys = []
        for uid in all_members:
            if uid == str(self.user_id):
                spki_bytes = self._identity['identity_pub_spki']
                pk_version = str(self._version)
            else:
                pk_info = self.get_public_keys(uid)
                if not pk_info or not pk_info.get('public_key'):
                    logger.warning(f"No XChat public key for user {uid}")
                    continue
                spki_bytes = base64.b64decode(pk_info['public_key'])
                pk_version = str(pk_info['version'])

            encrypted = ecies_wrap(c_key, spki_bytes)
            participant_keys.append({
                'user_id': str(uid),
                'encrypted_conversation_key': encrypted,
                'public_key_version': pk_version
            })

        if not participant_keys:
            logger.error(f"Cannot create conversation key: no participant keys found")
            return None

        # Upload lên server
        res = self._chat_gql('AddEncryptedConversationKeysMutation', {
            'conversation_id': conversation_id,
            'conversation_key_version': version,
            'conversation_participant_keys': participant_keys,
            'base64_encoded_key_rotation': None,
            'action_signatures': None,
            'ttl_msec': None
        })
        failure = None
        if res:
            failure = res.get('data', {}).get('xchat_add_encrypted_conversation_key', {}).get('error_code')
        if failure:
            logger.error(f"AddEncryptedConversationKeysMutation error: {failure}")
            return None

        self._ckeys[conversation_id] = {'key': c_key, 'version': version}
        logger.info(f"Created conversation key for {conversation_id}, version={version}")
        return self._ckeys[conversation_id]

    # -------------------------------------------------------
    # 5. Send message
    # -------------------------------------------------------

    def send_message(self, conversation_id: str, text: str, member_ids: Optional[List[str]] = None) -> bool:
        """
        Gửi tin nhắn E2EE vào X Chat conversation.
        member_ids: danh sách UID của các thành viên (cần để tạo ckey mới nếu chưa có)
        """
        # Đảm bảo có identity
        if not self.ensure_identity():
            raise RuntimeError("Không thể đăng ký XChat identity!")

        # Sync để lấy conversation key + token
        self.sync_conversation(conversation_id)

        # Nếu chưa có ckey, tạo mới
        if conversation_id not in self._ckeys:
            if not member_ids:
                raise RuntimeError(f"Chưa có conversation key cho {conversation_id} và không có member_ids để tạo mới!")
            ck = self.create_conversation_key(conversation_id, member_ids)
            if not ck:
                raise RuntimeError(f"Không thể tạo conversation key cho {conversation_id}!")

        ck = self._ckeys[conversation_id]
        token = self._tokens.get(conversation_id, '')
        message_id = str(uuid.uuid4())

        # Build plaintext Thrift
        plaintext_bytes = content_text(text)

        # Encrypt với nacl.secretbox
        frame = encrypt_body(plaintext_bytes, ck['key'])

        # Build MessageCreateEvent
        mce = message_create_event(frame, ck['version'], should_notify=True)

        # Sign
        sig = event_signature(
            signing_key=self._identity['signing_key'],
            signing_pub_b64=self._identity['signing_public_key_b64'],
            message_id=message_id,
            sender_id=self.user_id,
            conversation_id=conversation_id,
            conversation_key_version=ck['version'],
            frame=frame,
            my_version=self._version
        )

        # Send
        variables = {
            'conversation_id': conversation_id,
            'message_id': message_id,
            'conversation_token': token or None,
            'encoded_message_create_event': base64.b64encode(mce).decode(),
            'encoded_message_event_signature': sig
        }
        res = self._chat_gql('SendMessageCreateMutation', variables)
        event = res.get('data', {}).get('xchat_send_create_message_event') if res else None
        if event and event.get('encoded_message_event'):
            try:
                ev_bytes = base64.b64decode(event['encoded_message_event'])
                parsed = parse_thrift(ev_bytes)
                failure = parsed.get(7, {}).get(5) if isinstance(parsed.get(7), dict) else None
                if failure:
                    code = int(failure.get(1, 0)) if isinstance(failure, dict) else int(failure)
                    logger.error(f"XChat message rejected with failure code {code}")
                    return False
            except Exception as pe:
                logger.debug(f"parse encoded_message_event: {pe}")

            logger.info(f"XChat message sent to {conversation_id}")
            return True
        logger.error(f"SendMessageCreateMutation failed: {res}")
        return False
