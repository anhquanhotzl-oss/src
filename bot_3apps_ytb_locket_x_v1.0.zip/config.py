# -*- coding: utf-8 -*-
"""
Cấu hình Bot 3 Apps Mini (YouTube, Locket, X/Twitter).
"""
import os

BOT_TOKEN = "8620760869:AAGF9hEHjWszRKWrwEpzes3tRA4JQx4kg-s"
MASTER_ADMIN_ID = 7454964260
ADMIN_USERNAME = "@dzimeomeo"
ADMIN_CONTACT_URL = "https://t.me/dzimeomeo"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ADMINS_FILE = os.path.join(BASE_DIR, "admins.json")
TASKS_FILE = os.path.join(BASE_DIR, "tasks.json")
